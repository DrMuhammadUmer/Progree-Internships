"""Interactive Streamlit dashboard for customer and revenue analytics.
Run from the project root: streamlit run app.py
"""
from pathlib import Path
import sys
import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
import streamlit as st

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT / "src"))
from analysis_pipeline import add_rfm, cohort_analysis  # noqa: E402

st.set_page_config(page_title="Customer Analytics Portal", page_icon="📊", layout="wide")
st.title("Customer Segmentation & Behavioral Trends")
st.caption("Demonstration dashboard using synthetic retail data. Replace it with authorized company data before drawing business conclusions.")

data_path = ROOT / "outputs" / "cleaned_transactions.csv"
if not data_path.exists():
    st.error("Cleaned data was not found. Run `python src/analysis_pipeline.py --data data/retail_transactions_demo.csv --output outputs` first.")
    st.stop()

df = pd.read_csv(data_path, parse_dates=["InvoiceDate"])
min_date, max_date = df["InvoiceDate"].min().date(), df["InvoiceDate"].max().date()

with st.sidebar:
    st.header("Dashboard Filters")
    date_range = st.date_input("Invoice date range", value=(min_date, max_date), min_value=min_date, max_value=max_date)
    if isinstance(date_range, (tuple, list)):
        start_date = date_range[0] if len(date_range) > 0 and date_range[0] is not None else min_date
        end_date = date_range[1] if len(date_range) > 1 and date_range[1] is not None else max_date
    else:
        start_date = end_date = date_range
    categories = st.multiselect("Product category", sorted(df["ProductCategory"].dropna().unique()), default=sorted(df["ProductCategory"].dropna().unique()))
    countries = st.multiselect("Country", sorted(df["Country"].dropna().unique()), default=sorted(df["Country"].dropna().unique()))
    campaigns = st.multiselect("Campaign group", sorted(df["CampaignGroup"].dropna().unique()), default=sorted(df["CampaignGroup"].dropna().unique()))
    selected_segments = st.multiselect("RFM segment", ["Champions", "Loyal Customers", "Potential Loyalists", "At Risk", "Recent Customers", "Needs Attention"], default=["Champions", "Loyal Customers", "Potential Loyalists", "At Risk", "Recent Customers", "Needs Attention"])

filtered = df.loc[
    df["InvoiceDate"].dt.date.between(start_date, end_date)
    & df["ProductCategory"].isin(categories)
    & df["Country"].isin(countries)
    & df["CampaignGroup"].isin(campaigns)
].copy()
if filtered.empty:
    st.warning("No records match these filters. Change one or more filters.")
    st.stop()

rfm = add_rfm(filtered)
rfm = rfm.loc[rfm["Segment"].isin(selected_segments)]
revenue = float(filtered["Revenue"].sum())
orders = int(filtered["InvoiceNo"].nunique())
customers = int(filtered["CustomerID"].nunique())
avg_order = revenue / orders if orders else 0

k1, k2, k3, k4 = st.columns(4)
k1.metric("Revenue", f"{revenue:,.0f}")
k2.metric("Order Lines / Orders", f"{orders:,}")
k3.metric("Unique Customers", f"{customers:,}")
k4.metric("Average Sales per Order", f"{avg_order:,.2f}")

left, right = st.columns(2)
with left:
    daily = filtered.groupby("InvoiceDate", as_index=False)["Revenue"].sum()
    fig = px.line(daily, x="InvoiceDate", y="Revenue", title="Daily Revenue", markers=False)
    st.plotly_chart(fig, use_container_width=True)
with right:
    cat = filtered.groupby("ProductCategory", as_index=False)["Revenue"].sum().sort_values("Revenue", ascending=False)
    fig = px.bar(cat, x="ProductCategory", y="Revenue", title="Revenue by Category", color="ProductCategory")
    st.plotly_chart(fig, use_container_width=True)

left, right = st.columns(2)
with left:
    seg = rfm.groupby("Segment", as_index=False).agg(Customers=("CustomerID", "nunique"), Monetary=("Monetary", "sum"))
    fig = px.bar(seg, x="Segment", y="Customers", title="Selected RFM Segments", color="Segment")
    fig.update_layout(xaxis_tickangle=-20)
    st.plotly_chart(fig, use_container_width=True)
with right:
    country = filtered.groupby("Country", as_index=False)["Revenue"].sum()
    fig = px.choropleth(country, locations="Country", locationmode="country names", color="Revenue", hover_name="Country", title="Geospatial Revenue by Country")
    st.plotly_chart(fig, use_container_width=True)

st.subheader("Cohort Retention")
cohort_long, cohort_matrix = cohort_analysis(filtered)
if not cohort_matrix.empty:
    heat = cohort_matrix.set_index("CohortMonth")
    heat.columns = [c.replace("Month_", "Month ") for c in heat.columns]
    fig = px.imshow(heat, text_auto=".0%", aspect="auto", color_continuous_scale="Blues", zmin=0, zmax=1,
                    labels=dict(x="Months since first purchase", y="Cohort month", color="Retention"), title="Customer Cohort Retention Matrix")
    st.plotly_chart(fig, use_container_width=True)

st.subheader("RFM Customer Detail")
st.dataframe(rfm.sort_values("Monetary", ascending=False), use_container_width=True, hide_index=True)
st.download_button("Download current customer segments CSV", data=rfm.to_csv(index=False).encode("utf-8"), file_name="filtered_customer_rfm_segments.csv", mime="text/csv")
st.download_button("Download filtered transactions CSV", data=filtered.to_csv(index=False).encode("utf-8"), file_name="filtered_transactions.csv", mime="text/csv")

with st.expander("Definitions and cautions"):
    st.markdown("""
    - **Recency:** days since the customer's most recent purchase within the selected date range.
    - **Frequency:** distinct invoice count in the filtered sample.
    - **Monetary:** sum of derived gross sales in the filtered sample.
    - **Cohort retention:** share of customers from each first-purchase month who purchased again in each relative month.
    - This is a synthetic practice dataset; geospatial and behavior patterns are illustrative only.
    """)
