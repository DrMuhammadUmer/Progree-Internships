# Complete Data Analytics Tasks - Solution Package

This package addresses all four tasks from the supplied **Data Analytics Tasks & Instructions** PDF.

> **Important data note:** The PDF did not include an industry dataset or official internship offer letter. To make the technical work runnable end-to-end, the package includes a reproducible **synthetic retail transaction dataset**. All outputs, metrics, test results, plots, and sample dashboard findings are demonstrations only, not real company findings. Do not report demo figures as facts about Progree or any employer.

## What's included

- `TASK1_LinkedIn_Announcement.md` - polished LinkedIn caption and offer-letter posting checklist.
- `data/retail_transactions_demo.csv` - 20,200-row synthetic raw dataset with deliberately introduced data-quality issues.
- `src/generate_demo_data.py` - regenerates the sample data (fixed random seed).
- `src/analysis_pipeline.py` - reproducible cleaning, EDA, RFM, cohorts, hypothesis tests, regression evaluation, ARIMA forecasting, plots, and dashboard HTML.
- `notebooks/Complete_Data_Analytics_Solution.ipynb` - Jupyter notebook walkthrough of all four tasks.
- `app.py` - Streamlit dashboard with interactive date/category/country/campaign/segment filters, customer metrics, cohort chart, and country revenue map.
- `outputs/` - generated cleaned data, RFM and cohort data, test results, regression metrics/predictions, forecast with confidence intervals, figures, dashboard, and a results summary.
- `Task_Solution_Report.pdf` - concise report with methodology, demo results, and limitations.

## Task 1: LinkedIn announcement

Review `TASK1_LinkedIn_Announcement.md`. Attach your **actual official** offer letter in LinkedIn only after verifying it is approved for public sharing. The task source explicitly asks to tag Progree and include `#dataanalytics #python #tableau #progree`.

## Task 2: Exploratory Data Analysis & Integrity Cleaning Pipeline

The pipeline inspects types, missing values, exact duplicates and date quality. It then removes exact duplicates, parses mixed date formats, excludes invalid dates, removes impossible numeric rows (quantity or price at or below zero), excludes records with no customer identifier, imputes remaining numeric missing values with category medians and categorical missing values with modes, and caps `Quantity` / `UnitPrice` outliers using IQR fences. It derives `GrossSales = Quantity * UnitPrice * (1 - Discount)` for reconciliation and uses a provided `ReportedRevenue` field as the analysis outcome where available (falling back to `GrossSales` if the source field is absent or missing). It writes EDA plots.

This is a documented example policy, not a universal cleaning rule. Adapt it to your data dictionary; negative quantities may represent valid returns in some real datasets and should not automatically be deleted without domain review.

## Task 3: Customer Segmentation & Behavioral Trend Dashboard

RFM fields are computed as:

- **Recency:** days from each customer's last observed invoice to the day after the final observed date.
- **Frequency:** distinct invoice count.
- **Monetary:** sum of the analysis revenue field (provided ReportedRevenue in the demo dataset, with a calculated fallback).

The project assigns 1-5 R/F/M scores, applies transparent rule-based segments, calculates monthly cohort retention, exports Power BI/Tableau-ready CSVs, and provides a map by country. The standalone `outputs/demo_dashboard.html` contains interactive Plotly charts; `app.py` adds linked filters.

## Task 4: Statistical Inference & Predictive Business Forecasting

The pipeline includes:

1. **Welch two-sample t-test** comparing demo transaction sales for Campaign A and B; includes the difference and an approximate 95% confidence interval.
2. **One-way ANOVA** comparing average demo sales across product categories.
3. **Chi-square test** for association between campaign group and return flag.
4. **Random Forest regression** with an 80/20 train/test split; evaluates MAE, RMSE, and R-squared on held-out rows.
5. **ARIMA(1,1,1)** daily sales forecast for 30 days, with 95% confidence bounds.

P-values are not proof of causality, model scores are not meaningful without baselines, and forecasting intervals depend on model assumptions. The generated campaign uplift is included intentionally in the synthetic data for demonstration; it is not an experiment result from any real company.

## Run it locally

Recommended: Python 3.10+.

```bash
python -m venv .venv
# Windows PowerShell: .venv\\Scripts\\Activate.ps1
# macOS/Linux: source .venv/bin/activate
pip install -r requirements.txt
python src/analysis_pipeline.py --data data/retail_transactions_demo.csv --output outputs
streamlit run app.py
```

To rerun from newly generated synthetic data:

```bash
python src/generate_demo_data.py
python src/analysis_pipeline.py --data data/retail_transactions_demo.csv --output outputs
```

To use your actual company dataset, keep a backup, confirm permission to process it, map your fields to the required columns listed in `src/analysis_pipeline.py`, update cleaning assumptions, rerun the notebook and validate each output. Never fabricate or alter the official offer letter.

## Main output files

- `outputs/data_quality_summary.json`
- `outputs/cleaned_transactions.csv`
- `outputs/customer_rfm_segments.csv`
- `outputs/cohort_retention_long.csv` and `outputs/cohort_retention_matrix.csv`
- `outputs/hypothesis_test_results.csv`
- `outputs/regression_model_metrics.csv` and `outputs/regression_test_predictions.csv`
- `outputs/daily_revenue_forecast.csv`
- `outputs/demo_dashboard.html`
- `outputs/results_summary.md`
