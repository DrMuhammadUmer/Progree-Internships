"""Generate a reproducible, explicitly synthetic retail transaction dataset for demonstration."""
from pathlib import Path
import numpy as np
import pandas as pd

SEED = 42
N_ROWS = 20_000


def generate(path: str | Path = "data/retail_transactions_demo.csv", n_rows: int = N_ROWS, seed: int = SEED) -> pd.DataFrame:
    rng = np.random.default_rng(seed)
    start = np.datetime64("2025-01-01")
    day_offsets = rng.integers(0, 365, size=n_rows)
    dates = pd.to_datetime(start + day_offsets.astype("timedelta64[D]")).to_pydatetime()

    # Unequal customer probabilities create realistic repeat-purchase behavior.
    customer_ids = np.arange(10000, 12500)
    weights = 1 / np.power(np.arange(1, len(customer_ids) + 1), 0.75)
    weights = weights / weights.sum()
    chosen_customers = rng.choice(customer_ids, size=n_rows, p=weights).astype(object)

    countries = np.array(["United Kingdom", "Germany", "France", "Spain", "Netherlands", "United States", "Canada", "Australia"])
    country = rng.choice(countries, size=n_rows, p=[.33, .15, .12, .09, .08, .10, .06, .07])
    categories = np.array(["Home", "Technology", "Clothing", "Beauty", "Sports", "Books"])
    category = rng.choice(categories, size=n_rows, p=[.19, .18, .21, .14, .15, .13])
    category_price = {"Home": 55, "Technology": 145, "Clothing": 34, "Beauty": 22, "Sports": 48, "Books": 15}
    category_factor = {"Home": 1.07, "Technology": 1.45, "Clothing": .76, "Beauty": .68, "Sports": .92, "Books": .55}
    base_price = np.array([category_price[c] for c in category])
    unit_price = np.maximum(1.5, rng.lognormal(np.log(base_price), .42))
    quantity = rng.choice([1, 2, 3, 4, 5, 6, 7], size=n_rows, p=[.30, .24, .17, .12, .08, .05, .04])
    discount = np.round(rng.choice([0, .05, .10, .15, .20, .25, .30], size=n_rows, p=[.30, .12, .22, .14, .12, .07, .03]), 2)
    campaign = rng.choice(["A", "B"], size=n_rows, p=[.5, .5])
    returned = rng.binomial(1, np.where(campaign == "B", .065, .085), size=n_rows)
    payment = rng.choice(["Card", "PayPal", "Bank Transfer", "Cash"], size=n_rows, p=[.56, .25, .13, .06])

    # Generate an outcome with mild noise and a deliberately small campaign-B uplift.
    camp_uplift = np.where(campaign == "B", 1.08, 1.0)
    cat_uplift = np.array([category_factor[c] for c in category])
    noise = rng.lognormal(mean=0, sigma=.11, size=n_rows)
    revenue = quantity * unit_price * (1 - discount) * camp_uplift * cat_uplift * noise
    revenue = np.where(returned == 1, revenue * .08, revenue)

    df = pd.DataFrame({
        "InvoiceNo": [f"INV-{i+1:06d}" for i in range(n_rows)],
        "InvoiceDate": [pd.Timestamp(d).strftime("%Y-%m-%d") for d in dates],
        "CustomerID": chosen_customers,
        "Country": country,
        "ProductCategory": category,
        "Quantity": quantity.astype(float),
        "UnitPrice": unit_price.round(2),
        "Discount": discount,
        "PaymentMethod": payment,
        "CampaignGroup": campaign,
        "Returned": returned,
        "ReportedRevenue": revenue.round(2),
    })

    # Introduce data quality problems on purpose so Task 2 can demonstrate treatments.
    # Mixed formats / invalid dates
    date_indices = rng.choice(n_rows, size=160, replace=False)
    for j, idx in enumerate(date_indices):
        dt = pd.Timestamp(dates[idx])
        if j % 4 == 0:
            df.loc[idx, "InvoiceDate"] = dt.strftime("%d/%m/%Y")
        elif j % 4 == 1:
            df.loc[idx, "InvoiceDate"] = dt.strftime("%m-%d-%Y")
        elif j % 4 == 2:
            df.loc[idx, "InvoiceDate"] = "2025/19/40"  # invalid
        else:
            df.loc[idx, "InvoiceDate"] = "not-a-date"

    # Missing values: moderate and documented, for reproducible imputation practice.
    for col, fraction in [("Country", .012), ("ProductCategory", .008), ("Quantity", .006),
                          ("UnitPrice", .009), ("Discount", .014), ("PaymentMethod", .010),
                          ("CampaignGroup", .006), ("CustomerID", .012)]:
        idx = rng.choice(n_rows, size=int(n_rows * fraction), replace=False)
        df.loc[idx, col] = np.nan
    # Missing customer IDs are strings/IDs and are intentionally dropped in RFM-ready data.
    df["CustomerID"] = df["CustomerID"].astype(object)

    # Invalid numeric values plus a small number of influential outliers.
    invalid_q_idx = rng.choice(n_rows, size=24, replace=False)
    df.loc[invalid_q_idx[:12], "Quantity"] = -1
    df.loc[invalid_q_idx[12:], "Quantity"] = 0
    invalid_p_idx = rng.choice(n_rows, size=20, replace=False)
    df.loc[invalid_p_idx[:8], "UnitPrice"] = -12.5
    df.loc[invalid_p_idx[8:], "UnitPrice"] = 9999.0
    extreme_q_idx = rng.choice(n_rows, size=18, replace=False)
    df.loc[extreme_q_idx, "Quantity"] = 999

    # Add 1% exact duplicates.
    duplicate_rows = df.sample(frac=.01, random_state=seed)
    df = pd.concat([df, duplicate_rows], ignore_index=True)
    out = Path(path)
    if not out.is_absolute():
        out = Path(__file__).resolve().parents[1] / out
    out.parent.mkdir(parents=True, exist_ok=True)
    df.to_csv(out, index=False)
    return df


if __name__ == "__main__":
    df = generate()
    print(f"Saved {len(df):,} synthetic rows to data/retail_transactions_demo.csv")
