"""End-to-end solution for Tasks 2-4 in the supplied Data Analytics instructions.

This pipeline is designed for a synthetic practice retail dataset. Replace the input CSV
with an authorized real dataset and adjust column mappings before reporting business findings.
"""
from __future__ import annotations
from pathlib import Path
import json
import warnings

import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from scipy import stats
from sklearn.compose import ColumnTransformer
from sklearn.ensemble import RandomForestRegressor
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score
from sklearn.model_selection import train_test_split
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import OneHotEncoder
from statsmodels.tsa.arima.model import ARIMA
import plotly.express as px
import plotly.graph_objects as go
from plotly.subplots import make_subplots

RANDOM_STATE = 42


def parse_mixed_dates(series: pd.Series) -> pd.Series:
    """Parse dates with mixed common formats; invalid values become NaT, never guessed."""
    try:
        return pd.to_datetime(series, format="mixed", errors="coerce", dayfirst=False)
    except (TypeError, ValueError):
        return pd.to_datetime(series, errors="coerce")


def iqr_bounds(series: pd.Series, multiplier: float = 1.5) -> tuple[float, float]:
    q1 = float(series.quantile(.25))
    q3 = float(series.quantile(.75))
    iqr = q3 - q1
    return max(float(series.min()), q1 - multiplier * iqr), q3 + multiplier * iqr


def clean_data(raw: pd.DataFrame) -> tuple[pd.DataFrame, dict]:
    expected = ["InvoiceNo", "InvoiceDate", "CustomerID", "Country", "ProductCategory", "Quantity",
                "UnitPrice", "Discount", "PaymentMethod", "CampaignGroup", "Returned"]
    missing_cols = [c for c in expected if c not in raw.columns]
    if missing_cols:
        raise ValueError(f"Input file is missing required columns: {missing_cols}")
    df = raw.copy()
    diag = {
        "raw_rows": int(len(df)),
        "raw_columns": int(df.shape[1]),
        "raw_exact_duplicates": int(df.duplicated().sum()),
        "missing_before": {k: int(v) for k, v in df.isna().sum().items()},
        "raw_date_invalid_after_parse": 0,
        "dropped_invalid_dates": 0,
        "dropped_missing_customer_ids": 0,
        "dropped_invalid_numeric_rows": 0,
        "rows_capped_for_iqr_outliers": 0,
    }

    # Remove exact duplicate records first.
    df = df.drop_duplicates().copy()
    df["InvoiceDate"] = parse_mixed_dates(df["InvoiceDate"])
    diag["raw_date_invalid_after_parse"] = int(df["InvoiceDate"].isna().sum())
    before = len(df)
    df = df.loc[df["InvoiceDate"].notna()].copy()
    diag["dropped_invalid_dates"] = int(before - len(df))

    # Types and impossible values.
    for col in ["Quantity", "UnitPrice", "Discount"]:
        df[col] = pd.to_numeric(df[col], errors="coerce")
    df["Returned"] = pd.to_numeric(df["Returned"], errors="coerce").fillna(0).clip(0, 1).astype(int)
    # Quantity <= 0 and UnitPrice <= 0 are treated as invalid because these demo records
    # are line-level sales; refunds should be modeled separately in an actual business dataset.
    invalid_numeric = (df["Quantity"].le(0) & df["Quantity"].notna()) | (df["UnitPrice"].le(0) & df["UnitPrice"].notna())
    diag["dropped_invalid_numeric_rows"] = int(invalid_numeric.sum())
    df = df.loc[~invalid_numeric].copy()

    # Drop rows without an ID: imputing an identity would corrupt customer-level RFM.
    before = len(df)
    df["CustomerID"] = df["CustomerID"].astype("string").str.strip()
    df.loc[df["CustomerID"].isin(["", "nan", "None", "<NA>"]), "CustomerID"] = pd.NA
    df = df.loc[df["CustomerID"].notna()].copy()
    diag["dropped_missing_customer_ids"] = int(before - len(df))

    # Impute categorical fields by mode, or 'Unknown' if a field has no observed mode.
    cat_cols = ["Country", "ProductCategory", "PaymentMethod", "CampaignGroup"]
    for col in cat_cols:
        df[col] = df[col].astype("string").str.strip()
        df.loc[df[col].isin(["", "nan", "None", "<NA>"]), col] = pd.NA
        mode = df[col].mode(dropna=True)
        fill_value = str(mode.iloc[0]) if not mode.empty else "Unknown"
        df[col] = df[col].fillna(fill_value)

    # Discount is a fraction. Invalid values are treated as missing; then imputed by category median.
    df.loc[~df["Discount"].between(0, 1), "Discount"] = np.nan
    for col in ["Quantity", "UnitPrice", "Discount"]:
        group_median = df.groupby("ProductCategory", dropna=False)[col].transform("median")
        df[col] = df[col].fillna(group_median).fillna(df[col].median())

    # IQR capping reduces leverage from extreme values while retaining observations.
    # Bounds are calculated across the cleaned sample, separately by category for UnitPrice.
    capped_rows = set()
    for col in ["Quantity", "UnitPrice"]:
        if col == "UnitPrice":
            for _, idx in df.groupby("ProductCategory").groups.items():
                lo, hi = iqr_bounds(df.loc[idx, col])
                before_values = df.loc[idx, col].copy()
                df.loc[idx, col] = df.loc[idx, col].clip(lo, hi)
                capped_rows.update(before_values.index[(before_values != df.loc[idx, col])].tolist())
        else:
            lo, hi = iqr_bounds(df[col])
            before_values = df[col].copy()
            df[col] = df[col].clip(lo, hi)
            capped_rows.update(df.index[(before_values != df[col])].tolist())
    diag["rows_capped_for_iqr_outliers"] = int(len(capped_rows))

    df["Quantity"] = df["Quantity"].round().clip(lower=1).astype(int)
    df["Discount"] = df["Discount"].clip(0, .95)
    df["Returned"] = df["Returned"].astype(int)
    df["GrossSales"] = (df["Quantity"] * df["UnitPrice"] * (1 - df["Discount"])).round(2)
    # Prefer a provided business revenue field when available; use the arithmetic calculation as fallback.
    # This makes the chosen outcome explicit while retaining GrossSales for reconciliation.
    if "ReportedRevenue" in df.columns:
        df["ReportedRevenue"] = pd.to_numeric(df["ReportedRevenue"], errors="coerce")
        df["Revenue"] = df["ReportedRevenue"].fillna(df["GrossSales"])
    else:
        df["Revenue"] = df["GrossSales"]
    df["InvoiceMonth"] = df["InvoiceDate"].dt.to_period("M").astype(str)
    df["InvoiceDate"] = df["InvoiceDate"].dt.normalize()
    df = df.sort_values(["InvoiceDate", "InvoiceNo"]).reset_index(drop=True)

    diag["clean_rows"] = int(len(df))
    diag["clean_columns"] = int(df.shape[1])
    diag["missing_after"] = {k: int(v) for k, v in df.isna().sum().items()}
    diag["clean_exact_duplicates"] = int(df.duplicated().sum())
    return df, diag


def add_rfm(clean: pd.DataFrame) -> pd.DataFrame:
    as_of = clean["InvoiceDate"].max() + pd.Timedelta(days=1)
    grouped = clean.groupby("CustomerID", dropna=False).agg(
        LastPurchase=("InvoiceDate", "max"),
        Frequency=("InvoiceNo", "nunique"),
        Monetary=("Revenue", "sum"),
        Transactions=("InvoiceNo", "count"),
        ReturnedOrders=("Returned", "sum"),
        Country=("Country", lambda x: x.mode().iloc[0] if not x.mode().empty else "Unknown"),
    ).reset_index()
    grouped["Recency"] = (as_of - grouped["LastPurchase"]).dt.days
    grouped["ReturnRate"] = np.where(grouped["Transactions"] > 0, grouped["ReturnedOrders"] / grouped["Transactions"], 0)

    # rank(method='first') ensures exactly five bins even if many values are tied.
    grouped["R_Score"] = pd.qcut(grouped["Recency"].rank(method="first"), 5, labels=[5, 4, 3, 2, 1]).astype(int)
    grouped["F_Score"] = pd.qcut(grouped["Frequency"].rank(method="first"), 5, labels=[1, 2, 3, 4, 5]).astype(int)
    grouped["M_Score"] = pd.qcut(grouped["Monetary"].rank(method="first"), 5, labels=[1, 2, 3, 4, 5]).astype(int)

    def segment(row):
        r, f, m = row["R_Score"], row["F_Score"], row["M_Score"]
        if r >= 4 and f >= 4 and m >= 4:
            return "Champions"
        if f >= 4 and r >= 3:
            return "Loyal Customers"
        if r >= 4 and f >= 2:
            return "Potential Loyalists"
        if r <= 2 and f >= 3:
            return "At Risk"
        if r >= 4 and f <= 2:
            return "Recent Customers"
        return "Needs Attention"

    grouped["Segment"] = grouped.apply(segment, axis=1)
    return grouped.sort_values(["Segment", "Monetary"], ascending=[True, False]).reset_index(drop=True)


def cohort_analysis(clean: pd.DataFrame) -> tuple[pd.DataFrame, pd.DataFrame]:
    df = clean[["CustomerID", "InvoiceDate"]].copy()
    df["OrderMonth"] = df["InvoiceDate"].dt.to_period("M")
    df["CohortMonth"] = df.groupby("CustomerID")["OrderMonth"].transform("min")
    df["CohortIndex"] = (df["OrderMonth"].dt.year - df["CohortMonth"].dt.year) * 12 + (
        df["OrderMonth"].dt.month - df["CohortMonth"].dt.month) + 1
    cohort_data = df.groupby(["CohortMonth", "CohortIndex"])["CustomerID"].nunique().reset_index(name="ActiveCustomers")
    cohort_sizes = df.groupby("CohortMonth")["CustomerID"].nunique().rename("CohortSize")
    cohort_data = cohort_data.join(cohort_sizes, on="CohortMonth")
    cohort_data["RetentionRate"] = cohort_data["ActiveCustomers"] / cohort_data["CohortSize"]
    cohort_data["CohortMonth"] = cohort_data["CohortMonth"].astype(str)
    matrix = cohort_data.pivot(index="CohortMonth", columns="CohortIndex", values="RetentionRate")
    matrix.columns = [f"Month_{int(c)}" for c in matrix.columns]
    return cohort_data, matrix.reset_index()


def inferential_tests(clean: pd.DataFrame) -> pd.DataFrame:
    rows = []
    # Welch's two-sample t-test: transaction-level sales for randomized demo campaign groups.
    a = clean.loc[clean["CampaignGroup"].eq("A"), "Revenue"].dropna()
    b = clean.loc[clean["CampaignGroup"].eq("B"), "Revenue"].dropna()
    t_stat, p_value = stats.ttest_ind(b, a, equal_var=False)
    se = np.sqrt(a.var(ddof=1) / len(a) + b.var(ddof=1) / len(b))
    crit = stats.t.ppf(.975, df=max(1, min(len(a), len(b)) - 1))
    diff = b.mean() - a.mean()
    rows.append({"Test": "Welch t-test: Campaign B vs A mean Revenue", "Metric": "Mean difference (B-A)",
                 "GroupA": float(a.mean()), "GroupB": float(b.mean()), "Statistic": float(t_stat), "p_value": float(p_value),
                 "Effect_or_CI_low": float(diff - crit * se), "CI_high": float(diff + crit * se), "Interpretation_at_0.05": "Statistically significant difference" if p_value < .05 else "No statistically significant difference"})

    groups = [g["Revenue"].dropna().values for _, g in clean.groupby("ProductCategory") if len(g) > 1]
    cat_names = list(clean.groupby("ProductCategory").groups.keys())
    if len(groups) >= 2:
        f_stat, p_anova = stats.f_oneway(*groups)
        means = clean.groupby("ProductCategory")["Revenue"].mean()
        rows.append({"Test": "One-way ANOVA: Revenue by ProductCategory", "Metric": "Category mean sales differ", "GroupA": float(means.min()), "GroupB": float(means.max()), "Statistic": float(f_stat), "p_value": float(p_anova), "Effect_or_CI_low": np.nan, "CI_high": np.nan, "Interpretation_at_0.05": "At least one category mean differs" if p_anova < .05 else "No evidence of category mean differences"})

    contingency = pd.crosstab(clean["CampaignGroup"], clean["Returned"])
    if contingency.shape == (2, 2):
        chi2, p_chi, dof, expected = stats.chi2_contingency(contingency)
        rows.append({"Test": "Chi-square: CampaignGroup vs Returned", "Metric": "Association between group and return flag", "GroupA": np.nan, "GroupB": np.nan, "Statistic": float(chi2), "p_value": float(p_chi), "Effect_or_CI_low": np.nan, "CI_high": np.nan, "Interpretation_at_0.05": "Evidence of association" if p_chi < .05 else "No evidence of association"})
    return pd.DataFrame(rows)


def regression_model(clean: pd.DataFrame) -> tuple[pd.DataFrame, dict]:
    frame = clean[["Quantity", "UnitPrice", "Discount", "ProductCategory", "Country", "CampaignGroup", "Revenue"]].dropna().copy()
    X = frame.drop(columns="Revenue")
    y = frame["Revenue"]
    numeric = ["Quantity", "UnitPrice", "Discount"]
    categorical = ["ProductCategory", "Country", "CampaignGroup"]
    prep = ColumnTransformer([("numeric", "passthrough", numeric),
                              ("categorical", OneHotEncoder(handle_unknown="ignore"), categorical)])
    model = Pipeline([("prep", prep), ("model", RandomForestRegressor(n_estimators=180, min_samples_leaf=2, random_state=RANDOM_STATE, n_jobs=-1))])
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=.20, random_state=RANDOM_STATE)
    model.fit(X_train, y_train)
    pred = model.predict(X_test)
    metrics = {"Model": "RandomForestRegressor", "Target": "Revenue", "TestRows": int(len(y_test)),
               "MAE": float(mean_absolute_error(y_test, pred)), "RMSE": float(np.sqrt(mean_squared_error(y_test, pred))),
               "R2": float(r2_score(y_test, pred)), "TrainTestSplit": "80/20", "RandomState": RANDOM_STATE}
    pred_df = pd.DataFrame({"ActualRevenue": y_test.to_numpy(), "PredictedRevenue": pred})
    return pred_df, metrics


def forecast_daily_revenue(clean: pd.DataFrame, horizon: int = 30) -> tuple[pd.DataFrame, dict]:
    daily = clean.groupby("InvoiceDate")["Revenue"].sum().sort_index()
    full_idx = pd.date_range(daily.index.min(), daily.index.max(), freq="D")
    daily = daily.reindex(full_idx, fill_value=0.0)
    with warnings.catch_warnings():
        warnings.simplefilter("ignore")
        model = ARIMA(daily.astype(float), order=(1, 1, 1)).fit()
        fc = model.get_forecast(steps=horizon)
        mean = fc.predicted_mean
        ci = fc.conf_int(alpha=.05)
    forecast = pd.DataFrame({"Date": mean.index, "ForecastRevenue": mean.values,
                             "Lower95": ci.iloc[:, 0].values, "Upper95": ci.iloc[:, 1].values})
    history = pd.DataFrame({"Date": daily.index, "ActualRevenue": daily.values})
    summary = {"Model": "ARIMA(1,1,1)", "HistoricalDays": int(len(daily)), "ForecastHorizonDays": int(horizon),
               "MeanDailyForecast": float(forecast["ForecastRevenue"].mean()),
               "FirstForecastDate": str(forecast["Date"].min().date()), "LastForecastDate": str(forecast["Date"].max().date()),
               "Note": "Forecast is illustrative and should be benchmarked against seasonal-naive and business baselines."}
    return forecast, {"forecast": summary, "history": history}


def create_figures(clean: pd.DataFrame, rfm: pd.DataFrame, cohort_matrix: pd.DataFrame,
                   forecast: pd.DataFrame, forecast_history: pd.DataFrame, out_dir: Path) -> list[Path]:
    out_dir.mkdir(parents=True, exist_ok=True)
    files = []

    fig, ax = plt.subplots(figsize=(9, 5))
    clean["Revenue"].clip(upper=clean["Revenue"].quantile(.99)).hist(bins=45, ax=ax)
    ax.set_title("Revenue Distribution (clipped at 99th percentile for display)")
    ax.set_xlabel("Revenue")
    ax.set_ylabel("Transactions")
    p = out_dir / "revenue_distribution.png"
    fig.tight_layout(); fig.savefig(p, dpi=160); plt.close(fig); files.append(p)

    category = clean.groupby("ProductCategory", as_index=False).agg(Revenue=("Revenue", "sum"), Orders=("InvoiceNo", "nunique"))
    fig, ax = plt.subplots(figsize=(9, 5))
    category.sort_values("Revenue").plot(kind="barh", x="ProductCategory", y="Revenue", legend=False, ax=ax)
    ax.set_title("Total Revenue by Product Category")
    ax.set_xlabel("Revenue"); ax.set_ylabel("")
    p = out_dir / "revenue_by_category.png"
    fig.tight_layout(); fig.savefig(p, dpi=160); plt.close(fig); files.append(p)

    segment = rfm.groupby("Segment", as_index=False).agg(Customers=("CustomerID", "nunique"), Monetary=("Monetary", "sum"))
    fig, ax = plt.subplots(figsize=(9, 5))
    segment.sort_values("Customers").plot(kind="barh", x="Segment", y="Customers", legend=False, ax=ax)
    ax.set_title("Customer Count by RFM Segment"); ax.set_xlabel("Customers"); ax.set_ylabel("")
    p = out_dir / "rfm_segment_counts.png"
    fig.tight_layout(); fig.savefig(p, dpi=160); plt.close(fig); files.append(p)

    # Cohort heatmap
    if not cohort_matrix.empty:
        cm = cohort_matrix.set_index("CohortMonth")
        cm.columns = [c.replace("Month_", "M") for c in cm.columns]
        fig, ax = plt.subplots(figsize=(12, 6))
        im = ax.imshow(cm.to_numpy(dtype=float), aspect="auto", vmin=0, vmax=1)
        ax.set_yticks(range(len(cm.index)), labels=cm.index)
        ax.set_xticks(range(len(cm.columns)), labels=cm.columns)
        ax.set_title("Monthly Customer Cohort Retention")
        ax.set_xlabel("Months since first purchase"); ax.set_ylabel("Acquisition cohort")
        fig.colorbar(im, ax=ax, label="Retention rate")
        p = out_dir / "cohort_retention_heatmap.png"
        fig.tight_layout(); fig.savefig(p, dpi=160); plt.close(fig); files.append(p)

    fig, ax = plt.subplots(figsize=(11, 5))
    ax.plot(forecast_history["Date"], forecast_history["ActualRevenue"], label="Historical daily revenue", linewidth=1)
    ax.plot(forecast["Date"], forecast["ForecastRevenue"], label="ARIMA forecast", linewidth=2)
    ax.fill_between(forecast["Date"], forecast["Lower95"], forecast["Upper95"], alpha=.2, label="95% interval")
    ax.set_title("Daily Revenue Forecast (illustrative 30-day horizon)"); ax.set_ylabel("Revenue"); ax.legend()
    p = out_dir / "daily_revenue_forecast.png"
    fig.tight_layout(); fig.savefig(p, dpi=160); plt.close(fig); files.append(p)
    return files


def create_dashboard_html(clean: pd.DataFrame, rfm: pd.DataFrame, cohort: pd.DataFrame,
                          forecast: pd.DataFrame, out_file: Path) -> None:
    daily = clean.groupby("InvoiceDate", as_index=False)["Revenue"].sum()
    category = clean.groupby("ProductCategory", as_index=False).agg(Revenue=("Revenue", "sum"), Orders=("InvoiceNo", "nunique"))
    segments = rfm.groupby("Segment", as_index=False).agg(Customers=("CustomerID", "nunique"), Monetary=("Monetary", "sum"))
    country = clean.groupby("Country", as_index=False)["Revenue"].sum()
    fig1 = px.line(daily, x="InvoiceDate", y="Revenue", title="Daily Revenue Trend")
    fig2 = px.bar(category, x="ProductCategory", y="Revenue", title="Revenue by Product Category")
    fig3 = px.bar(segments, x="Segment", y="Customers", title="Customer Segments")
    fig4 = px.choropleth(country, locations="Country", locationmode="country names", color="Revenue", hover_name="Country", title="Revenue by Country")
    hist = clean.groupby("InvoiceDate", as_index=False)["Revenue"].sum()
    fig5 = go.Figure()
    fig5.add_trace(go.Scatter(x=hist["InvoiceDate"], y=hist["Revenue"], mode="lines", name="Historical"))
    fig5.add_trace(go.Scatter(x=forecast["Date"], y=forecast["ForecastRevenue"], mode="lines", name="Forecast"))
    fig5.add_trace(go.Scatter(x=list(forecast["Date"]) + list(forecast["Date"][::-1]),
                              y=list(forecast["Upper95"]) + list(forecast["Lower95"][::-1]),
                              fill="toself", line=dict(width=0), name="95% interval", opacity=.18))
    fig5.update_layout(title="Revenue Forecast with 95% Confidence Interval")
    figs = [fig1, fig2, fig3, fig4, fig5]
    html_parts = ["<!doctype html><html><head><meta charset='utf-8'><title>Data Analytics Demo Dashboard</title>",
                  "<style>body{font-family:Arial,sans-serif;margin:28px;color:#17202a}h1{margin-bottom:4px}.note{background:#f5f6f7;padding:12px;border-radius:8px}.chart{margin:20px 0}</style></head><body>",
                  "<h1>Customer & Revenue Analytics Dashboard</h1>",
                  "<p class='note'><strong>Demo only:</strong> based on synthetic retail data generated for this task. Results are not real company findings. For linked filters and live slicing, run <code>streamlit run app.py</code> from the project folder.</p>"]
    for i, fig in enumerate(figs):
        html_parts.append("<div class='chart'>")
        html_parts.append(fig.to_html(full_html=False, include_plotlyjs=True if i == 0 else False))
        html_parts.append("</div>")
    html_parts.append("</body></html>")
    out_file.write_text("\n".join(html_parts), encoding="utf-8")


def run_pipeline(data_path: str | Path, output_dir: str | Path) -> dict:
    data_path = Path(data_path)
    output_dir = Path(output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)
    figures_dir = output_dir / "figures"
    raw = pd.read_csv(data_path, low_memory=False)
    clean, quality = clean_data(raw)
    rfm = add_rfm(clean)
    cohort_long, cohort_matrix = cohort_analysis(clean)
    tests = inferential_tests(clean)
    pred_df, reg_metrics = regression_model(clean)
    forecast, forecast_package = forecast_daily_revenue(clean, horizon=30)
    history = forecast_package["history"]

    # Write outputs
    clean.to_csv(output_dir / "cleaned_transactions.csv", index=False)
    rfm.to_csv(output_dir / "customer_rfm_segments.csv", index=False)
    cohort_long.to_csv(output_dir / "cohort_retention_long.csv", index=False)
    cohort_matrix.to_csv(output_dir / "cohort_retention_matrix.csv", index=False)
    tests.to_csv(output_dir / "hypothesis_test_results.csv", index=False)
    pred_df.to_csv(output_dir / "regression_test_predictions.csv", index=False)
    pd.DataFrame([reg_metrics]).to_csv(output_dir / "regression_model_metrics.csv", index=False)
    forecast.to_csv(output_dir / "daily_revenue_forecast.csv", index=False)
    history.to_csv(output_dir / "daily_revenue_history.csv", index=False)
    pd.DataFrame([quality]).to_json(output_dir / "data_quality_summary.json", orient="records", indent=2, date_format="iso")
    pd.DataFrame([reg_metrics]).to_json(output_dir / "regression_metrics.json", orient="records", indent=2)
    (output_dir / "forecast_summary.json").write_text(json.dumps(forecast_package["forecast"], indent=2), encoding="utf-8")

    figs = create_figures(clean, rfm, cohort_matrix, forecast, history, figures_dir)
    create_dashboard_html(clean, rfm, cohort_long, forecast, output_dir / "demo_dashboard.html")

    total = float(clean["Revenue"].sum())
    summary = {
        "dataset_notice": "All reported values below come from synthetic demo data, not an actual company dataset.",
        "raw_rows": int(len(raw)), "clean_rows": int(len(clean)), "unique_customers": int(rfm["CustomerID"].nunique()),
        "total_revenue": round(total, 2), "average_order_line_revenue": round(float(clean["Revenue"].mean()), 2),
        "segments": {str(k): int(v) for k, v in rfm["Segment"].value_counts().items()},
        "top_category_by_sales": str(clean.groupby("ProductCategory")["Revenue"].sum().idxmax()),
        "hypothesis_tests": tests.to_dict(orient="records"),
        "regression": reg_metrics, "forecast": forecast_package["forecast"],
        "output_files": ["cleaned_transactions.csv", "customer_rfm_segments.csv", "cohort_retention_long.csv", "cohort_retention_matrix.csv", "hypothesis_test_results.csv", "regression_model_metrics.csv", "daily_revenue_forecast.csv", "demo_dashboard.html"],
    }
    (output_dir / "results_summary.json").write_text(json.dumps(summary, indent=2, default=str), encoding="utf-8")
    (output_dir / "results_summary.md").write_text(render_summary_markdown(summary, quality), encoding="utf-8")
    return {"summary": summary, "quality": quality, "tests": tests, "figures": figs}


def render_summary_markdown(summary: dict, quality: dict) -> str:
    lines = ["# Data Analytics Results Summary", "", "> **Important:** The input bundled with this project is synthetic practice data. The numerical findings below demonstrate the method only and must not be presented as findings about a real business.", "",
             "## Data quality and cleaning", f"- Raw rows after loading: {quality['raw_rows']:,}",
             f"- Exact duplicates detected and removed: {quality['raw_exact_duplicates']:,}",
             f"- Invalid dates after parsing: {quality['raw_date_invalid_after_parse']:,}",
             f"- Rows dropped for invalid dates: {quality['dropped_invalid_dates']:,}",
             f"- Rows dropped for missing customer IDs: {quality['dropped_missing_customer_ids']:,}",
             f"- Rows dropped for impossible numeric values: {quality['dropped_invalid_numeric_rows']:,}",
             f"- Rows with outliers capped using IQR fences: {quality['rows_capped_for_iqr_outliers']:,}",
             f"- Clean rows: {summary['clean_rows']:,}", "",
             "## Descriptive analysis", f"- Unique customers represented: {summary['unique_customers']:,}",
             f"- Total revenue: {summary['total_revenue']:,.2f}",
             f"- Average revenue per transaction line: {summary['average_order_line_revenue']:,.2f}",
             f"- Highest-sales category in the demo sample: {summary['top_category_by_sales']}", "",
             "## Customer segmentation", "| Segment | Customers |", "|---|---:|"]
    lines.extend([f"| {k} | {v:,} |" for k, v in summary["segments"].items()])
    lines += ["", "## Statistical tests", "| Test | Statistic | p-value | Conclusion at alpha=0.05 |", "|---|---:|---:|---|"]
    for row in summary["hypothesis_tests"]:
        p_display = "<1e-300 (numeric underflow)" if row["p_value"] == 0 else f"{row['p_value']:.6g}"
        lines.append(f"| {row['Test']} | {row['Statistic']:.4f} | {p_display} | {row['Interpretation_at_0.05']} |")
    reg = summary["regression"]
    fc = summary["forecast"]
    lines += ["", "## Predictive modeling", f"- Regression model: {reg['Model']}", f"- Test R-squared: {reg['R2']:.3f}",
              f"- Test MAE: {reg['MAE']:.2f}", f"- Test RMSE: {reg['RMSE']:.2f}",
              f"- Forecast model: {fc['Model']}", f"- Forecast horizon: {fc['ForecastHorizonDays']} days ({fc['FirstForecastDate']} to {fc['LastForecastDate']})",
              f"- Mean forecast daily revenue: {fc['MeanDailyForecast']:.2f}", "",
              "## Interpretation and limitations", "- p-values address statistical evidence, not business importance or causality.",
              "- The campaign effect exists by design in the synthetic generator; do not interpret this as a real A/B test.",
              "- The ARIMA interval represents model uncertainty under its assumptions and is not a guarantee.",
              "- Before using real data, check data definitions, assignment randomization, independence, seasonality, leakage, and business context.",
              "- Check the charts in `figures/` and use `streamlit run app.py` for a filterable dashboard.", ""]
    return "\n".join(lines)


if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--data", default="data/retail_transactions_demo.csv", help="Input transaction CSV")
    parser.add_argument("--output", default="outputs", help="Output directory")
    args = parser.parse_args()
    result = run_pipeline(args.data, args.output)
    print(result["summary"]["dataset_notice"])
    print(f"Clean rows: {result['summary']['clean_rows']:,}; unique customers: {result['summary']['unique_customers']:,}")
    print(f"Outputs written to: {Path(args.output).resolve()}")
