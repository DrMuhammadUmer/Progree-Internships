from pathlib import Path
import json
import pandas as pd
from reportlab.lib import colors
from reportlab.lib.enums import TA_CENTER, TA_LEFT
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.units import mm
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle, Image, PageBreak, KeepTogether

ROOT = Path(__file__).resolve().parent
OUT = ROOT / "Task_Solution_Report.pdf"
outputs = ROOT / "outputs"
summary = json.loads((outputs / "results_summary.json").read_text(encoding="utf-8"))
quality = json.loads((outputs / "data_quality_summary.json").read_text(encoding="utf-8"))[0]
tests = pd.read_csv(outputs / "hypothesis_test_results.csv")
segments = pd.read_csv(outputs / "customer_rfm_segments.csv").groupby("Segment").agg(Customers=("CustomerID", "nunique"), Revenue=("Monetary", "sum")).reset_index()
reg = summary["regression"]
forecast = summary["forecast"]

styles = getSampleStyleSheet()
styles.add(ParagraphStyle(name="CoverTitle", parent=styles["Title"], fontName="Helvetica-Bold", fontSize=25, leading=31, alignment=TA_CENTER, textColor=colors.HexColor("#15324B"), spaceAfter=12))
styles.add(ParagraphStyle(name="SubTitle", parent=styles["Normal"], fontName="Helvetica", fontSize=12, leading=17, alignment=TA_CENTER, textColor=colors.HexColor("#476174"), spaceAfter=12))
styles.add(ParagraphStyle(name="H1X", parent=styles["Heading1"], fontName="Helvetica-Bold", fontSize=16, leading=20, textColor=colors.HexColor("#15324B"), spaceBefore=5, spaceAfter=8))
styles.add(ParagraphStyle(name="H2X", parent=styles["Heading2"], fontName="Helvetica-Bold", fontSize=11, leading=14, textColor=colors.HexColor("#1F5872"), spaceBefore=7, spaceAfter=5))
styles.add(ParagraphStyle(name="BodyX", parent=styles["BodyText"], fontName="Helvetica", fontSize=9, leading=13, spaceAfter=5))
styles.add(ParagraphStyle(name="SmallX", parent=styles["BodyText"], fontName="Helvetica", fontSize=7.7, leading=10, textColor=colors.HexColor("#3B4650"), spaceAfter=3))
styles.add(ParagraphStyle(name="Caution", parent=styles["BodyText"], fontName="Helvetica-Bold", fontSize=9, leading=13, textColor=colors.HexColor("#8A3F16"), backColor=colors.HexColor("#FFF3E6"), borderColor=colors.HexColor("#F1C58B"), borderWidth=.6, borderPadding=7, spaceBefore=4, spaceAfter=9))


def p(txt, style="BodyX"):
    return Paragraph(txt, styles[style])


def table(data, widths, header=True, font_size=8):
    t = Table(data, colWidths=widths, repeatRows=1 if header else 0, hAlign="LEFT")
    commands = [
        ("VALIGN", (0, 0), (-1, -1), "TOP"),
        ("LEFTPADDING", (0, 0), (-1, -1), 5), ("RIGHTPADDING", (0, 0), (-1, -1), 5),
        ("TOPPADDING", (0, 0), (-1, -1), 4), ("BOTTOMPADDING", (0, 0), (-1, -1), 4),
        ("GRID", (0, 0), (-1, -1), .35, colors.HexColor("#CBD5DC")),
        ("FONTSIZE", (0, 0), (-1, -1), font_size),
    ]
    if header:
        commands += [("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#15324B")),
                     ("TEXTCOLOR", (0, 0), (-1, 0), colors.white),
                     ("FONTNAME", (0, 0), (-1, 0), "Helvetica-Bold")]
    for r in range(1 if header else 0, len(data)):
        if r % 2 == 0:
            commands.append(("BACKGROUND", (0, r), (-1, r), colors.HexColor("#F3F7F9")))
    t.setStyle(TableStyle(commands))
    return t


def footer(canvas, doc):
    canvas.saveState()
    w, h = A4
    canvas.setStrokeColor(colors.HexColor("#D4DEE5"))
    canvas.line(18*mm, 14*mm, w-18*mm, 14*mm)
    canvas.setFont("Helvetica", 7.5)
    canvas.setFillColor(colors.HexColor("#61717D"))
    canvas.drawString(18*mm, 9*mm, "Data Analytics Complete Solution - synthetic demonstration data")
    canvas.drawRightString(w-18*mm, 9*mm, f"Page {doc.page}")
    canvas.restoreState()

story = []
# Cover / summary
story += [Spacer(1, 26*mm), p("DATA ANALYTICS TASKS", "CoverTitle"), p("Complete Solution Report", "SubTitle"), Spacer(1, 8*mm)]
story.append(p("Coverage: LinkedIn announcement, data integrity and exploratory analysis, customer segmentation and cohort dashboard, inferential statistics and business forecasting.", "BodyX"))
story.append(Spacer(1, 3*mm))
story.append(p("IMPORTANT DATA LIMITATION: The supplied instruction PDF contained task descriptions only; it did not include the original industry dataset or an internship offer letter. To provide a runnable end-to-end solution, the technical examples use a reproducible synthetic retail dataset. All numbers and findings in this report are illustrative and must not be presented as real company results.", "Caution"))
story.append(p("Executive summary", "H1X"))
summary_rows = [
    ["Metric", "Demo result"],
    ["Raw records", f"{summary['raw_rows']:,}"],
    ["Clean records retained", f"{summary['clean_rows']:,}"],
    ["Unique customers", f"{summary['unique_customers']:,}"],
    ["Total revenue in demo data", f"{summary['total_revenue']:,.2f}"],
    ["Top demo category by revenue", str(summary["top_category_by_sales"])],
    ["Regression model", f"{reg['Model']} (test R-squared {reg['R2']:.3f})"],
    ["Forecast", f"{forecast['Model']}, {forecast['ForecastHorizonDays']}-day horizon"],
]
story.append(table(summary_rows, [58*mm, 105*mm]))
story.append(Spacer(1, 5*mm))
story.append(p("Deliverables included with the ZIP", "H2X"))
story.append(p("Runnable Jupyter notebook, Python analysis pipeline, demo data generator, Streamlit dashboard application, Plotly HTML dashboard, cleaning diagnostics, RFM and cohort CSVs, hypothesis-test outputs, regression evaluation, forecast intervals, and LinkedIn caption draft.", "BodyX"))
story.append(PageBreak())

# Task 1/2
story.append(p("Task 1 - Professional LinkedIn Announcement", "H1X"))
story.append(p("Caption draft", "H2X"))
story.append(p("I'm excited to share that I've officially started my Data Analytics Internship with <b>@Progree</b>! I'm looking forward to strengthening my practical skills in <b>Python, Tableau, exploratory data analysis, data cleaning, customer segmentation, and data-driven business problem-solving</b>. I'm grateful for the opportunity to learn, contribute, and turn data into clear, actionable insights. Looking forward to learning from the team and making the most of this experience! #dataanalytics #python #tableau #progree", "BodyX"))
story.append(p("Before posting: select the actual Progree company page so it is tagged; attach the official offer letter in high resolution only after checking the acceptance and public-sharing permission. The original letter was not included and must not be fabricated.", "SmallX"))
story.append(p("Task 2 - Exploratory Data Analysis and Integrity Cleaning", "H1X"))
quality_rows = [["Data quality check", "Count"],
                ["Raw rows", f"{quality['raw_rows']:,}"],
                ["Exact duplicates detected and removed", f"{quality['raw_exact_duplicates']:,}"],
                ["Invalid dates after parsing", f"{quality['raw_date_invalid_after_parse']:,}"],
                ["Rows dropped for invalid dates", f"{quality['dropped_invalid_dates']:,}"],
                ["Rows dropped for missing customer IDs", f"{quality['dropped_missing_customer_ids']:,}"],
                ["Rows dropped for impossible quantity/price", f"{quality['dropped_invalid_numeric_rows']:,}"],
                ["Rows affected by IQR outlier capping", f"{quality['rows_capped_for_iqr_outliers']:,}"],
                ["Clean rows retained", f"{quality['clean_rows']:,}"]]
story.append(table(quality_rows, [106*mm, 57*mm]))
story.append(Spacer(1, 3*mm))
story.append(p("Cleaning policy", "H2X"))
story.append(p("The pipeline removes exact duplicate rows; parses mixed date formats; drops invalid dates instead of inventing timestamps; excludes impossible non-positive quantity/price records and rows without customer IDs; imputes numeric missing values by product-category median (with global median fallback); imputes categorical values by mode; and caps Quantity and UnitPrice using IQR fences. It derives GrossSales from quantity, price and discount for reconciliation, while preferring a provided ReportedRevenue column as the analysis outcome. This is a sample policy and must be revised for real data, particularly where negative quantities represent valid refunds.", "BodyX"))
img_path = outputs / "figures" / "revenue_distribution.png"
if img_path.exists():
    story.append(Image(str(img_path), width=150*mm, height=83*mm))
story.append(PageBreak())

# Task 3
story.append(p("Task 3 - Customer Segmentation and Behavioral Trends", "H1X"))
story.append(p("RFM definitions", "H2X"))
story.append(p("Recency = days since the customer's last observed purchase; Frequency = distinct invoices; Monetary = total revenue. Scores from 1 to 5 are assigned using quantile buckets. Rule-based segments include Champions, Loyal Customers, Potential Loyalists, At Risk, Recent Customers, and Needs Attention.", "BodyX"))
seg_rows = [["RFM segment", "Customers", "Total demo revenue"]]
for _, r in segments.sort_values("Customers", ascending=False).iterrows():
    seg_rows.append([str(r["Segment"]), f"{int(r['Customers']):,}", f"{float(r['Revenue']):,.0f}"])
story.append(table(seg_rows, [66*mm, 38*mm, 59*mm]))
story.append(Spacer(1, 4*mm))
for filename, width, height in [("rfm_segment_counts.png", 135*mm, 66*mm), ("cohort_retention_heatmap.png", 160*mm, 70*mm)]:
    image_path = outputs / "figures" / filename
    if image_path.exists():
        story.append(Image(str(image_path), width=width, height=height))
        story.append(Spacer(1, 2*mm))
story.append(p("The Streamlit dashboard (app.py) supports date, category, country, campaign and RFM segment filters; shows daily revenue, category contribution, customer segments and a country revenue map; and allows exporting filtered transaction and RFM CSV files. The CSV exports can also be imported into Power BI or Tableau.", "SmallX"))
story.append(PageBreak())

# Task 4
story.append(p("Task 4 - Inferential Statistics and Predictive Forecasting", "H1X"))
story.append(p("Hypothesis tests", "H2X"))
test_rows = [["Test", "Statistic", "p-value", "Interpretation at alpha = 0.05"]]
for _, r in tests.iterrows():
    pv = float(r["p_value"])
    ptxt = "<1e-300*" if pv == 0 else (f"{pv:.3g}" if pv < .001 else f"{pv:.4f}")
    test_rows.append([str(r["Test"]), f"{float(r['Statistic']):.3f}", ptxt, str(r["Interpretation_at_0.05"])])
story.append(table(test_rows, [62*mm, 22*mm, 29*mm, 50*mm], font_size=7))
story.append(p("*A zero p-value in this output reflects floating-point underflow for an extremely small computed p-value, not a literally zero probability.", "SmallX"))
story.append(p("The Welch t-test compares transaction revenue in demo Campaign A vs B, ANOVA checks whether mean revenue differs across product categories, and chi-square tests association between campaign group and return status. Statistical significance does not establish causality or business value. The synthetic generator deliberately adds a campaign uplift and different return probabilities, so these results are for method demonstration only.", "BodyX"))
story.append(p("Regression and forecast evaluation", "H2X"))
model_rows = [["Evaluation", "Result"],
              ["Regression model", str(reg["Model"])],
              ["Target", str(reg["Target"])],
              ["Test rows", f"{reg['TestRows']:,}"],
              ["Test R-squared", f"{reg['R2']:.3f}"],
              ["Test MAE", f"{reg['MAE']:.2f}"],
              ["Test RMSE", f"{reg['RMSE']:.2f}"],
              ["Forecast model", str(forecast["Model"])],
              ["Forecast dates", f"{forecast['FirstForecastDate']} to {forecast['LastForecastDate']}"],
              ["Mean forecast daily revenue", f"{forecast['MeanDailyForecast']:,.2f}"]]
story.append(table(model_rows, [70*mm, 93*mm]))
img_path = outputs / "figures" / "daily_revenue_forecast.png"
if img_path.exists():
    story.append(Spacer(1, 4*mm))
    story.append(Image(str(img_path), width=145*mm, height=60*mm))
story.append(p("Limitations: benchmark the regression against simple baselines and check for leakage; evaluate forecasting against seasonal-naive and business baselines; revisit temporal split and seasonality assumptions; and validate test assumptions and practical effect sizes using real data.", "SmallX"))
story.append(Spacer(1, 3*mm))
story.append(p("Reproducibility", "H2X"))
story.append(p("From the project folder, install requirements.txt, run `python src/analysis_pipeline.py --data data/retail_transactions_demo.csv --output outputs`, then run `streamlit run app.py`. The notebook contains the end-to-end walkthrough and displays generated tables and charts.", "BodyX"))

doc = SimpleDocTemplate(str(OUT), pagesize=A4, rightMargin=18*mm, leftMargin=18*mm, topMargin=16*mm, bottomMargin=19*mm, title="Data Analytics Complete Solution Report", author="OpenAI")
doc.build(story, onFirstPage=footer, onLaterPages=footer)
print(f"Created {OUT} ({OUT.stat().st_size:,} bytes)")
