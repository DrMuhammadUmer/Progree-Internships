# Data Analytics Results Summary

> **Important:** The input bundled with this project is synthetic practice data. The numerical findings below demonstrate the method only and must not be presented as findings about a real business.

## Data quality and cleaning
- Raw rows after loading: 20,200
- Exact duplicates detected and removed: 200
- Invalid dates after parsing: 80
- Rows dropped for invalid dates: 80
- Rows dropped for missing customer IDs: 239
- Rows dropped for impossible numeric values: 32
- Rows with outliers capped using IQR fences: 691
- Clean rows: 19,649

## Descriptive analysis
- Unique customers represented: 2,412
- Total revenue: 3,283,917.72
- Average revenue per transaction line: 167.13
- Highest-sales category in the demo sample: Technology

## Customer segmentation
| Segment | Customers |
|---|---:|
| Needs Attention | 919 |
| Champions | 497 |
| At Risk | 336 |
| Loyal Customers | 320 |
| Potential Loyalists | 289 |
| Recent Customers | 51 |

## Statistical tests
| Test | Statistic | p-value | Conclusion at alpha=0.05 |
|---|---:|---:|---|
| Welch t-test: Campaign B vs A mean Revenue | 3.5850 | 0.000337861 | Statistically significant difference |
| One-way ANOVA: Revenue by ProductCategory | 2661.9116 | <1e-300 (numeric underflow) | At least one category mean differs |
| Chi-square: CampaignGroup vs Returned | 23.6940 | 1.12932e-06 | Evidence of association |

## Predictive modeling
- Regression model: RandomForestRegressor
- Test R-squared: 0.878
- Test MAE: 35.47
- Test RMSE: 98.12
- Forecast model: ARIMA(1,1,1)
- Forecast horizon: 30 days (2026-01-01 to 2026-01-30)
- Mean forecast daily revenue: 8251.74

## Interpretation and limitations
- p-values address statistical evidence, not business importance or causality.
- The campaign effect exists by design in the synthetic generator; do not interpret this as a real A/B test.
- The ARIMA interval represents model uncertainty under its assumptions and is not a guarantee.
- Before using real data, check data definitions, assignment randomization, independence, seasonality, leakage, and business context.
- Check the charts in `figures/` and use `streamlit run app.py` for a filterable dashboard.
