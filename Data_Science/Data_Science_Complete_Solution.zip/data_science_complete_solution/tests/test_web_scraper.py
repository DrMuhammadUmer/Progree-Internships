from pathlib import Path
from task2_web_scraper import parse_listing_page


def test_parse_and_clean_fixture():
    root = Path(__file__).resolve().parents[1]
    html = (root / "data" / "fixtures" / "scraper_sample_page.html").read_text(encoding="utf-8")
    rows = parse_listing_page(html, "https://example.invalid/fixture", "2026-10-13T00:00:00+00:00")
    assert len(rows) == 2
    assert rows[0]["author"] == "Demo Analyst"
    assert rows[0]["tags"] == "analytics|demo"
    assert rows[0]["quote_word_count"] > 0
    assert all(r["source_url"] == "https://example.invalid/fixture" for r in rows)
