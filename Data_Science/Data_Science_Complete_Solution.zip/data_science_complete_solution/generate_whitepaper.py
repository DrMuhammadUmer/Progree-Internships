"""Create a six-page PDF whitepaper from generated Task 2-4 artifacts."""
from pathlib import Path
import json
import pandas as pd
from reportlab.lib import colors
from reportlab.lib.enums import TA_CENTER, TA_LEFT
from reportlab.lib.pagesizes import letter
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.units import inch
from reportlab.platypus import (SimpleDocTemplate, Paragraph, Spacer, PageBreak, Image,
                                Table, TableStyle, KeepTogether, HRFlowable)

ROOT = Path(__file__).resolve().parent
OUT = ROOT / "Data_Science_Whitepaper.pdf"
outputs = ROOT / "outputs"
figures = ROOT / "figures"
model = json.loads((outputs / "time_series_model_results.json").read_text(encoding="utf-8"))
clusters = pd.read_csv(outputs / "cluster_summary.csv")
diag = pd.read_csv(outputs / "cluster_diagnostics.csv")
importance = pd.read_csv(outputs / "feature_importance_shap.csv")
forecast = pd.read_csv(outputs / "sales_forecast_12_months.csv")

NAVY = colors.HexColor('#15324B')
TEAL = colors.HexColor('#178F92')
PALE = colors.HexColor('#EAF2F6')
MID = colors.HexColor('#4B6475')
LIGHT = colors.HexColor('#F5F8FA')
GRID = colors.HexColor('#D7E1E7')
DARK = colors.HexColor('#263746')

styles = getSampleStyleSheet()
styles.add(ParagraphStyle(name='CoverTitle2', parent=styles['Title'], fontName='Helvetica-Bold', fontSize=27, leading=32, textColor=NAVY, alignment=TA_LEFT, spaceAfter=14))
styles.add(ParagraphStyle(name='Subtitle2', parent=styles['Normal'], fontName='Helvetica', fontSize=12, leading=17, textColor=MID, spaceAfter=12))
styles.add(ParagraphStyle(name='Section2', parent=styles['Heading1'], fontName='Helvetica-Bold', fontSize=17, leading=21, textColor=NAVY, spaceBefore=1, spaceAfter=10))
styles.add(ParagraphStyle(name='Subhead2', parent=styles['Heading2'], fontName='Helvetica-Bold', fontSize=11, leading=14, textColor=TEAL, spaceBefore=7, spaceAfter=5))
styles.add(ParagraphStyle(name='Body2', parent=styles['BodyText'], fontName='Helvetica', fontSize=8.6, leading=12.2, textColor=DARK, spaceAfter=5))
styles.add(ParagraphStyle(name='Small2', parent=styles['BodyText'], fontName='Helvetica', fontSize=7.2, leading=9.1, textColor=DARK, spaceAfter=3))
styles.add(ParagraphStyle(name='Tiny2', parent=styles['BodyText'], fontName='Helvetica', fontSize=6.4, leading=8, textColor=DARK))
styles.add(ParagraphStyle(name='Callout2', parent=styles['BodyText'], fontName='Helvetica-Bold', fontSize=8.4, leading=11.6, textColor=NAVY, spaceAfter=0))
styles.add(ParagraphStyle(name='TableHead2', parent=styles['BodyText'], fontName='Helvetica-Bold', fontSize=7.1, leading=8.5, textColor=colors.white))
styles.add(ParagraphStyle(name='TableCell2', parent=styles['BodyText'], fontName='Helvetica', fontSize=6.9, leading=8.2, textColor=DARK))
styles.add(ParagraphStyle(name='CenterSmall2', parent=styles['BodyText'], fontName='Helvetica', fontSize=8, leading=10, alignment=TA_CENTER, textColor=MID))


def P(text, style='Body2'):
    return Paragraph(text, styles[style])


def page_decoration(canvas, doc):
    canvas.saveState()
    w, h = letter
    if doc.page > 1:
        canvas.setStrokeColor(GRID)
        canvas.setLineWidth(0.5)
        canvas.line(42, h - 33, w - 42, h - 33)
        canvas.setFont('Helvetica-Bold', 7)
        canvas.setFillColor(NAVY)
        canvas.drawString(42, h - 25, 'DATA SCIENCE PROJECT WHITEPAPER')
    canvas.setStrokeColor(GRID)
    canvas.line(42, 31, w - 42, 31)
    canvas.setFont('Helvetica', 7)
    canvas.setFillColor(MID)
    canvas.drawString(42, 19, 'Tasks 2-4 | Synthetic demonstration data; see limitations')
    canvas.drawRightString(w - 42, 19, f'Page {doc.page}')
    canvas.restoreState()


def mk_table(data, widths=None, header=True, font_size=7, padd=5):
    table = Table(data, colWidths=widths, repeatRows=1 if header else 0, hAlign='LEFT')
    commands = [
        ('VALIGN', (0, 0), (-1, -1), 'TOP'),
        ('LEFTPADDING', (0, 0), (-1, -1), padd),
        ('RIGHTPADDING', (0, 0), (-1, -1), padd),
        ('TOPPADDING', (0, 0), (-1, -1), padd),
        ('BOTTOMPADDING', (0, 0), (-1, -1), padd),
        ('GRID', (0, 0), (-1, -1), 0.35, GRID),
        ('FONTSIZE', (0, 0), (-1, -1), font_size),
        ('TEXTCOLOR', (0, 0), (-1, -1), DARK),
    ]
    if header:
        commands += [('BACKGROUND', (0, 0), (-1, 0), NAVY), ('TEXTCOLOR', (0, 0), (-1, 0), colors.white)]
        if len(data) > 1:
            commands += [('ROWBACKGROUNDS', (0, 1), (-1, -1), [colors.white, LIGHT])]
    table.setStyle(TableStyle(commands))
    return table


def callout(text, width=7.15*inch):
    t = Table([[P(text, 'Callout2')]], colWidths=[width])
    t.setStyle(TableStyle([
        ('BACKGROUND', (0,0), (-1,-1), PALE), ('BOX', (0,0), (-1,-1), .7, TEAL),
        ('LEFTPADDING', (0,0), (-1,-1), 9), ('RIGHTPADDING', (0,0), (-1,-1), 9),
        ('TOPPADDING', (0,0), (-1,-1), 8), ('BOTTOMPADDING', (0,0), (-1,-1), 8),
    ]))
    return t


def img(path, width, height):
    im = Image(str(path), width=width, height=height)
    im.hAlign = 'CENTER'
    return im

story = []
# Page 1: executive cover
story += [Spacer(1, 0.42*inch), P('DATA SCIENCE<br/>PROJECT WHITEPAPER', 'CoverTitle2'),
          HRFlowable(width='100%', thickness=3, color=TEAL, spaceBefore=2, spaceAfter=18),
          P('Automated web extraction, unsupervised customer segmentation, and time-series forecasting with a model interpretability layer', 'Subtitle2'),
          Spacer(1, 0.12*inch),
          P('Scope: Tasks 2-4 from the provided Data Science Tasks &amp; Instructions. Task 1 is intentionally excluded in line with the earlier request.', 'Body2'),
          Spacer(1, 0.08*inch), P('Executive summary', 'Subhead2'),
          P('This package demonstrates a reproducible data science workflow. Task 2 supplies a polite BeautifulSoup scraper and a parser test fixture. Task 3 uses standardized behavioral metrics, K-Means diagnostics, and PCA to create four illustrative customer segments. Task 4 evaluates stationarity, fits a seasonal SARIMAX model, forecasts twelve months with 95% intervals, and uses SHAP to interpret an auxiliary one-step Random Forest model.', 'Body2'),
          Spacer(1, 0.08*inch)]

key_data = [
    [P('CUSTOMER DATA', 'TableHead2'), P('FORECAST', 'TableHead2'), P('VALIDATION', 'TableHead2')],
    [P('<b>1,200</b><br/>synthetic customer rows<br/>4 clusters', 'TableCell2'),
     P('<b>Oct 2026 - Sep 2027</b><br/>12 monthly periods<br/>95% confidence intervals', 'TableCell2'),
     P('<b>3.63% MAPE</b><br/>12-month holdout<br/>SARIMAX demonstration', 'TableCell2')],
]
story += [mk_table(key_data, [2.35*inch, 2.35*inch, 2.35*inch], header=False, padd=10), Spacer(1, 0.22*inch),
          callout('DATA INTEGRITY: no real customer or historical business data was supplied. Tasks 3-4 use synthetic demonstration records. The scraper code is complete, but live web retrieval could not be performed in this build environment; bundled parser rows are explicitly marked as offline test fixtures, not real scraped data.'),
          Spacer(1, 0.18*inch), P('Deliverable files', 'Subhead2'),
          P('Python scraper and analysis pipeline, an interactive Streamlit dashboard, Jupyter notebook, generated CSV outputs, diagnostics, chart images, and this six-page whitepaper are included in the project archive.', 'Body2'),
          P('Prepared: October 2026 | Reproducible demo build', 'CenterSmall2'), PageBreak()]

# Page 2: task 2
story += [P('2 | Task 2 - Automated web scraping and extraction', 'Section2'),
          P('Objective: collect public text listings from an unstructured HTML source, extract core fields with text-selection logic, clean whitespace, and save the result to CSV and a database.', 'Body2'),
          P('Implementation', 'Subhead2'),
          P('<b>Source target:</b> Quotes to Scrape (https://quotes.toscrape.com/), a public practice site intended for scraping exercises. The script uses Requests with retries and a descriptive user-agent. It follows pagination links, applies a configurable delay, and stops at a configurable maximum number of pages.', 'Body2'),
          P('<b>Parsing and cleaning:</b> BeautifulSoup selects each <font name="Courier">div.quote</font>, reads the quote text and author, extracts all tags, replaces non-breaking and zero-width spaces, collapses repeated whitespace, rejects blank/short/unusable text, computes character and word counts, then removes duplicate quote-author pairs.', 'Body2'),
          P('Output schema', 'Subhead2')]
schema = [
    [P('Field', 'TableHead2'), P('Definition', 'TableHead2'), P('Treatment', 'TableHead2')],
    [P('quote', 'TableCell2'), P('Main text listing', 'TableCell2'), P('Whitespace normalized; empty text excluded', 'TableCell2')],
    [P('author', 'TableCell2'), P('Attributed author name', 'TableCell2'), P('Whitespace normalized; required for record', 'TableCell2')],
    [P('tags', 'TableCell2'), P('Page tags joined by |', 'TableCell2'), P('Blank tags omitted', 'TableCell2')],
    [P('source_url', 'TableCell2'), P('URL of page captured', 'TableCell2'), P('Retained for lineage', 'TableCell2')],
    [P('scraped_at_utc', 'TableCell2'), P('Capture timestamp', 'TableCell2'), P('UTC ISO timestamp', 'TableCell2')],
    [P('quote_char_count / quote_word_count', 'TableCell2'), P('Derived text metrics', 'TableCell2'), P('Calculated after cleanup', 'TableCell2')],
]
story += [mk_table(schema, [1.65*inch, 2.5*inch, 2.9*inch], padd=4), Spacer(1, 0.12*inch),
          P('Storage and reproducibility', 'Subhead2'),
          P('A successful live run writes <font name="Courier">quotes_scraped.csv</font> and <font name="Courier">quotes_scraped.sqlite</font>, with records stored in the <font name="Courier">quote_records</font> table. A local HTML fixture and parser test verify extraction offline. The included fixture export contains only made-up demo rows with source_url set to example.invalid; it must not be cited as live-collected data.', 'Body2'),
          callout('Run from the project folder: python task2_web_scraper.py --pages 5 --output-dir outputs/task2_live_scrape --delay 1. Internet connectivity is required. Check terms of service and robots policies when changing the target; do not bypass access controls.'), PageBreak()]

# Page 3: clustering methods
story += [P('3 | Task 3 - Unsupervised customer segmentation', 'Section2'),
          P('The demonstration uses 1,200 synthetic customer records with demographic, purchase-frequency, order-value, channel and return-rate metrics. A small number of missing online-ratio values are intentionally present in the raw file to demonstrate data preparation.', 'Body2'),
          P('Pipeline', 'Subhead2'),
          P('<b>1. Data quality:</b> remove duplicate customer IDs; coerce feature columns to numeric; median-impute missing numeric values; clip numeric values to the 1st and 99th percentiles to reduce the influence of extreme values. In real data, compare such treatments with domain limits and robust methods before clipping.', 'Body2'),
          P('<b>2. Standardization:</b> apply StandardScaler to age, annual income, spending score, monthly purchase frequency, average order value, online purchase ratio and return rate. Standardization is important because the raw metrics have different units and ranges.', 'Body2'),
          P('<b>3. Cluster diagnostics:</b> fit K-Means for k=2 through k=8, recording inertia for the elbow method and silhouette score for cohesion/separation. The demo selects k=4 because the synthetic data was intentionally generated from four latent profiles; this is not evidence that a real customer dataset should use four clusters.', 'Body2'),
          P('<b>4. Projection:</b> PCA maps the standardized feature matrix into two principal components for visual inspection. PCA is a visual reduction, not a replacement for cluster validation in the full feature space.', 'Body2'),
          P('Elbow diagnostic', 'Subhead2'),
          img(figures / 'elbow_method.png', 6.7*inch, 2.72*inch),
          P('The elbow curve should be evaluated jointly with silhouette scores, cluster stability, profile interpretability, and practical business usefulness. The complete diagnostic table is available at <font name="Courier">outputs/cluster_diagnostics.csv</font>.', 'Small2'), PageBreak()]

# Page 4: segmentation results
story += [P('4 | Customer segment profiles and interpretation', 'Section2'),
          P('The final cluster labels are descriptive names generated from the average behavior profiles. They are convenient summaries, not ground-truth customer classes.', 'Body2')]
cl_data = [[P('Segment', 'TableHead2'), P('Customers', 'TableHead2'), P('Share', 'TableHead2'), P('Income (k)', 'TableHead2'), P('Spend score', 'TableHead2'), P('Purchases/mo', 'TableHead2'), P('AOV', 'TableHead2')]]
for _, r in clusters.iterrows():
    cl_data.append([P(str(r['segment_name']), 'TableCell2'), P(f"{int(r['customers']):,}", 'TableCell2'), P(f"{r['customer_share_pct']:.1f}%", 'TableCell2'),
                    P(f"{r['avg_income_k']:.1f}", 'TableCell2'), P(f"{r['avg_spending_score']:.1f}", 'TableCell2'),
                    P(f"{r['avg_monthly_frequency']:.2f}", 'TableCell2'), P(f"{r['avg_order_value']:.1f}", 'TableCell2')])
story += [mk_table(cl_data, [1.65*inch, .68*inch, .62*inch, .7*inch, .78*inch, .8*inch, .62*inch], padd=4),
          Spacer(1, .12*inch), img(figures / 'customer_pca_clusters.png', 6.55*inch, 3.55*inch),
          P('Illustrative profile reading', 'Subhead2'),
          P('<b>Premium Loyalists:</b> higher average income, order value, spend score and transaction frequency. In a real setting, test retention benefits and avoid over-discounting customers who already buy regularly.', 'Small2'),
          P('<b>High-Potential Shoppers:</b> above-average spend and frequency, with high online engagement. Consider relevant cross-sell or loyalty tests, then measure incremental lift.', 'Small2'),
          P('<b>Digital Casuals:</b> high online ratio but comparatively low purchase frequency and order value. Evaluate low-friction repeat-purchase journeys.', 'Small2'),
          P('<b>Occasional Value Seekers:</b> lower purchase frequency and lower typical order value. Evaluate value messaging and test promotions against margin impact.', 'Small2'),
          PageBreak()]

# Page 5: time-series
adf = model['adf']; sar = model['sarima']
story += [P('5 | Task 4 - Time-series stationarity and SARIMAX forecast', 'Section2'),
          P('The time series contains 117 synthetic monthly sales observations from January 2017 through September 2026. It includes a gradual trend, recurring annual seasonality, a modest holiday uplift, and seeded noise. It represents a reproducible demonstration, not real company performance.', 'Body2'),
          P('Stationarity checks', 'Subhead2')]
adf_data = [
    [P('Series', 'TableHead2'), P('ADF statistic', 'TableHead2'), P('p-value', 'TableHead2'), P('Conclusion at 5%', 'TableHead2')],
    [P('Raw sales', 'TableCell2'), P(f"{adf['raw_adf_statistic']:.3f}", 'TableCell2'), P(f"{adf['raw_adf_p_value']:.4f}", 'TableCell2'), P('Fail to reject unit-root null; non-stationary evidence', 'TableCell2')],
    [P('12-month seasonal difference', 'TableCell2'), P(f"{adf['seasonal_diff_adf_statistic']:.3f}", 'TableCell2'), P(f"{adf['seasonal_diff_adf_p_value']:.4f}", 'TableCell2'), P('Reject unit-root null; stationary under this test', 'TableCell2')],
    [P('Seasonal + regular difference (check)', 'TableCell2'), P(f"{adf['seasonal_plus_regular_diff_adf_statistic']:.3f}", 'TableCell2'), P(f"{adf['seasonal_plus_regular_diff_adf_p_value']:.4f}", 'TableCell2'), P('Does not reject at 5%; differencing choice needs care', 'TableCell2')],
]
story += [mk_table(adf_data, [1.7*inch, 1.0*inch, .75*inch, 3.35*inch], padd=4),
          P('The fitted SARIMAX specification is order (1,0,1), seasonal order (1,1,1,12), consistent with seasonal differencing at a 12-month period. The last 12 historical months were held out for validation before refitting to the full series for future forecasting.', 'Body2'),
          P('Forecast with 95% confidence intervals', 'Subhead2'),
          img(figures / 'sales_forecast.png', 6.75*inch, 3.0*inch),
          P(f"Holdout metrics: MAE = {sar['validation_mae']:.2f}, RMSE = {sar['validation_rmse']:.2f}, MAPE = {sar['validation_mape_pct']:.2f}%. Forecast dates: {sar['forecast_start']} to {sar['forecast_end']}. Forecast average = {sar['forecast_mean']:.1f} sales units per month. Confidence bands communicate model uncertainty and should not be treated as guaranteed limits.", 'Small2'), PageBreak()]

# Page 6: interpretability, validation, limitations
story += [P('6 | Model interpretability, limitations and reproducibility', 'Section2'),
          P('SHAP feature contributions', 'Subhead2'),
          P('A separate Random Forest one-step-ahead model uses time index, month-of-year encoding, sales lags, and a three-month rolling average. SHAP TreeExplainer calculates per-feature contributions on a sample of 60 rows; average absolute SHAP values summarize the magnitude of contributions in the model output unit.', 'Body2'),
          img(figures / 'shap_feature_importance.png', 6.65*inch, 2.45*inch)]
imp_data = [[P('Feature', 'TableHead2'), P('Mean absolute SHAP', 'TableHead2'), P('Interpretation', 'TableHead2')]]
for _, r in importance.dropna(subset=['mean_abs_shap']).head(5).iterrows():
    f = str(r['feature'])
    desc = {
        'lag_12': 'Same month in the previous year; captures annual seasonality.',
        'time_index': 'Long-run temporal position; may capture underlying growth.',
        'lag_1': 'Previous month value; captures local persistence.',
        'month_cos': 'Calendar season position.',
        'month_sin': 'Calendar season position.',
        'lag_2': 'Sales two months earlier.',
        'rolling_mean_3': 'Recent three-month level (excluding current month).',
    }.get(f, 'Lag/calendar predictor in the auxiliary model.')
    imp_data.append([P(f, 'TableCell2'), P(f"{r['mean_abs_shap']:.2f}", 'TableCell2'), P(desc, 'TableCell2')])
story += [mk_table(imp_data, [1.25*inch, 1.35*inch, 4.15*inch], padd=4),
          Spacer(1, 0.07*inch),
          callout('Interpretation boundary: SHAP explains the auxiliary Random Forest, not the SARIMAX model itself. Lag_12 is the strongest driver in this demo, which is consistent with the seasonal structure built into the synthetic series; it does not establish a causal effect.'),
          P('Limitations and responsible use', 'Subhead2'),
          P('Synthetic data cannot support real commercial claims. Clipping and median imputation are teaching choices and should be validated against the real data-generating process. Cluster IDs are arbitrary; segment names are heuristic. The scraper must be run online for live records and adapted only after checking source policies. Forecast accuracy can change materially under structural breaks, promotions, stockouts, missing periods, or data revisions. A single train/holdout split is useful for demonstration but rolling-origin validation is preferable for production.', 'Small2'),
          P('Reproduce', 'Subhead2'),
          P('1. Install dependencies: <font name="Courier">pip install -r requirements.txt</font><br/>2. Regenerate Task 3/4: <font name="Courier">python analysis_pipeline.py</font><br/>3. Run live scraping: <font name="Courier">python task2_web_scraper.py --pages 5 --output-dir outputs/task2_live_scrape</font><br/>4. Launch dashboard: <font name="Courier">streamlit run dashboard.py</font><br/>5. Open <font name="Courier">Data_Science_Project_Notebook.ipynb</font> for a guided walkthrough.', 'Small2'),
          P('Source target for scraper implementation: Quotes to Scrape, https://quotes.toscrape.com/. All generated numeric results in this whitepaper are reproducible synthetic-demo outputs.', 'Tiny2')]

doc = SimpleDocTemplate(str(OUT), pagesize=letter, rightMargin=42, leftMargin=42, topMargin=47, bottomMargin=43,
                        title='Data Science Project Whitepaper - Tasks 2-4', author='OpenAI')
doc.build(story, onFirstPage=page_decoration, onLaterPages=page_decoration)
print(OUT)
