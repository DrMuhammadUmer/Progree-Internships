"""Interactive Streamlit dashboard for clustering, forecasting, and SHAP outputs."""
from pathlib import Path
import json
import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
import streamlit as st

ROOT = Path(__file__).resolve().parent
DATA = ROOT / "data"
OUT = ROOT / "outputs"
FIG = ROOT / "figures"

st.set_page_config(page_title="Data Science Project Dashboard", page_icon="📊", layout="wide")
st.title("Data Science Project Dashboard")
st.caption("Tasks 2-4 | Customer clusters, time-series forecast, and explainability. Demo data is synthetic unless a live scrape is run.")

required = [OUT / "customer_segments.csv", OUT / "cluster_summary.csv", OUT / "sales_forecast_12_months.csv", OUT / "feature_importance_shap.csv"]
if not all(p.exists() for p in required):
    st.error("Analysis outputs are missing. Open a terminal in the project folder and run: python analysis_pipeline.py")
    st.stop()

customers = pd.read_csv(OUT / "customer_segments.csv")
summary = pd.read_csv(OUT / "cluster_summary.csv")
history = pd.read_csv(DATA / "monthly_sales_synthetic.csv", parse_dates=["date"])
forecast = pd.read_csv(OUT / "sales_forecast_12_months.csv", parse_dates=["date"])
importance = pd.read_csv(OUT / "feature_importance_shap.csv")
results = json.loads((OUT / "time_series_model_results.json").read_text(encoding="utf-8"))
diagnostics = pd.read_csv(OUT / "cluster_diagnostics.csv")
silhouette_k4 = float(diagnostics.loc[diagnostics["k"] == 4, "silhouette_score"].iloc[0])

seg_tab, forecast_tab, explain_tab, scrape_tab = st.tabs(["Customer Segmentation", "Sales Forecast", "Model Interpretability", "Web Scraping"])

with seg_tab:
    c1, c2, c3 = st.columns(3)
    c1.metric("Customers", f"{len(customers):,}")
    c2.metric("Segments", customers["cluster_id"].nunique())
    c3.metric("Silhouette score (k=4)", f"{silhouette_k4:.3f}")
    segments = sorted(customers["segment_name"].dropna().unique().tolist())
    picked = st.multiselect("Filter segments", segments, default=segments)
    view = customers[customers["segment_name"].isin(picked)]
    fig = px.scatter(view, x="pca_1", y="pca_2", color="segment_name", hover_data=["customer_id", "annual_income_k", "spending_score", "purchase_frequency_monthly"], title="Customer groups projected into two PCA dimensions")
    st.plotly_chart(fig, use_container_width=True)
    st.subheader("Segment profile")
    st.dataframe(summary.round(2), use_container_width=True)
    st.download_button("Download filtered customer data", view.to_csv(index=False).encode("utf-8"), "customer_segments_filtered.csv", "text/csv")

with forecast_tab:
    st.write(f"Forecast window: **{forecast['date'].min().date()} to {forecast['date'].max().date()}**")
    fig = go.Figure()
    fig.add_trace(go.Scatter(x=history["date"], y=history["monthly_sales"], name="Historical sales", mode="lines"))
    fig.add_trace(go.Scatter(x=forecast["date"], y=forecast["upper_95"], name="Upper 95% CI", line=dict(width=0), showlegend=False, hoverinfo="skip"))
    fig.add_trace(go.Scatter(x=forecast["date"], y=forecast["lower_95"], name="95% confidence interval", fill="tonexty", line=dict(width=0), opacity=.25, hoverinfo="skip"))
    fig.add_trace(go.Scatter(x=forecast["date"], y=forecast["forecast_sales"], name="SARIMA forecast", mode="lines+markers"))
    st.plotly_chart(fig, use_container_width=True)
    a, b, c = st.columns(3)
    a.metric("Holdout MAE", f"{results['sarima']['validation_mae']:.1f}")
    b.metric("Holdout RMSE", f"{results['sarima']['validation_rmse']:.1f}")
    c.metric("Holdout MAPE", f"{results['sarima']['validation_mape_pct']:.2f}%")
    st.dataframe(forecast.round(2), use_container_width=True)
    st.download_button("Download forecast CSV", forecast.to_csv(index=False).encode("utf-8"), "sales_forecast_12_months.csv", "text/csv")

with explain_tab:
    st.info("SHAP values explain a Random Forest one-step-ahead model built from lag and calendar features. They do not directly decompose the SARIMAX forecast internals.")
    imp_col = "mean_abs_shap" if importance["mean_abs_shap"].notna().any() else "model_feature_importance"
    fig = px.bar(importance.sort_values(imp_col), x=imp_col, y="feature", orientation="h", title=f"Feature importance ({'mean absolute SHAP' if imp_col == 'mean_abs_shap' else 'Random Forest fallback'})")
    st.plotly_chart(fig, use_container_width=True)
    st.write("Stationarity checks")
    st.json(results["adf"])
    st.write("Top features:", ", ".join(results["sarima"]["top_features"]))
    st.download_button("Download feature importance CSV", importance.to_csv(index=False).encode("utf-8"), "feature_importance_shap.csv", "text/csv")

with scrape_tab:
    st.markdown("The live scraper in `task2_web_scraper.py` targets the public practice site [Quotes to Scrape](https://quotes.toscrape.com/). It writes a CSV and SQLite database after a live run.")
    live_csv = OUT / "task2_live_scrape" / "quotes_scraped.csv"
    if live_csv.exists():
        scraped = pd.read_csv(live_csv)
        st.success(f"Live scrape file found: {len(scraped):,} rows")
        st.dataframe(scraped.head(50), use_container_width=True)
        st.download_button("Download live scrape CSV", scraped.to_csv(index=False).encode("utf-8"), "quotes_scraped.csv", "text/csv")
    else:
        st.warning("No live scrape output is present yet. Run: python task2_web_scraper.py --pages 5 --output-dir outputs/task2_live_scrape")
        fixture = pd.read_csv(OUT / "task2_parser_test_output.csv") if (OUT / "task2_parser_test_output.csv").exists() else None
        if fixture is not None:
            st.caption("Offline parser fixture only - these are test rows, not live-scraped records.")
            st.dataframe(fixture, use_container_width=True)
