# Data Science Tasks - Complete Solution (Tasks 2-4)

This project implements the three technical tasks from **Data Science Tasks & Instructions.pdf**. Task 1 (the repeated LinkedIn announcement) is intentionally excluded, following the earlier request to remove Task 1.

## Included deliverables

- `task2_web_scraper.py` - polite public-page scraper using Requests + BeautifulSoup; extracts quote text, author, tags, source URL and derived length counts; cleans whitespace; removes duplicate records; writes CSV and SQLite.
- `analysis_pipeline.py` - generates deterministic synthetic customer and monthly-sales examples, performs K-Means clustering with standardization/PCA/elbow diagnostics, fits and validates SARIMAX, checks stationarity, forecasts 12 months with 95% intervals, and computes SHAP explanations for a Random Forest feature wrapper.
- `dashboard.py` - interactive Streamlit dashboard with customer segments, forecast, confidence intervals, SHAP importance and a live-scrape output viewer.
- `Data_Science_Project_Notebook.ipynb` - guided notebook.
- `Data_Science_Whitepaper.pdf` - six-page methods/results whitepaper.
- `data/` - synthetic demo datasets and a small HTML parser test fixture.
- `outputs/` - generated tables, model diagnostics and forecast results.
- `figures/` - elbow, PCA, forecast and SHAP charts.

## Important data integrity note

No real customer dataset, historical business dataset, or web-scrape export was supplied with the instruction PDF. To make the project runnable end-to-end, Tasks 3 and 4 use **synthetic demonstration data** generated with fixed random seeds. They are not real customer or enterprise findings. Task 2 is implemented against [Quotes to Scrape](https://quotes.toscrape.com/), a public practice site, but this build environment could not resolve the external host; therefore the included `task2_parser_test_output.csv` contains explicitly labelled offline parser-fixture records, not live-scraped records. Run the scraper from an internet-connected environment to create actual source records.

## Setup

Python 3.10 or newer is recommended.

```bash
python -m venv .venv
# Windows:
.venv\\Scripts\\activate
# macOS/Linux:
source .venv/bin/activate
pip install -r requirements.txt
```

## Run the pipelines

From this project directory:

```bash
python analysis_pipeline.py
```

This recreates synthetic datasets, customer segments, elbow/silhouette diagnostics, PCA chart, stationarity tests, SARIMAX validation, a 12-month forecast with 95% confidence intervals, a Random Forest SHAP explanation, and `outputs/project_results_summary.json`.

For live public-page scraping (internet required):

```bash
python task2_web_scraper.py --pages 5 --output-dir outputs/task2_live_scrape --delay 1
```

The script writes `outputs/task2_live_scrape/quotes_scraped.csv` and `outputs/task2_live_scrape/quotes_scraped.sqlite`. It uses retries, a user-agent, a delay between pages, and page-limit controls. Check the terms and robots policy before adapting it to another website. Do not use it to bypass authentication, CAPTCHAs or access controls.

Run the offline parser check with:

```bash
python -m pytest -q
```

Launch the dashboard:

```bash
streamlit run dashboard.py
```

Open the notebook in Jupyter and run cells top to bottom from the project directory.

## Methods summary

### Task 2 - Web extraction

The parser targets the practice site's `.quote`, `.text`, `.author`, `.tag`, and `li.next a` elements. It collapses whitespace, strips non-breaking/zero-width spacing, filters blank/unusable records, calculates quote character/word counts, drops duplicate quote-author pairs, and exports CSV + SQLite.

### Task 3 - Unsupervised customer segmentation

Seven numeric behavior/demographic features are median-imputed, clipped to the 1st/99th percentiles, and standardized. K-Means diagnostics are calculated for k=2..8 using inertia and silhouette score; the demo fit uses k=4 because its synthetic data was intentionally constructed from four latent profiles. PCA maps standardized features into two dimensions for visualization. In a real project, select k using diagnostics, stability, and business interpretability rather than assuming k=4.

### Task 4 - Time-series forecasting and interpretability

The 117-row monthly synthetic series runs from January 2017 through September 2026. ADF tests are calculated before and after 12-month seasonal differencing. The fitted model is SARIMAX order (1,0,1), seasonal order (1,1,1,12); a final 12-month holdout is used for validation, and a full-series refit produces a 12-month forecast and 95% intervals. SHAP TreeExplainer interprets an auxiliary Random Forest one-step-ahead model using lag and calendar variables. SHAP values do **not** directly decompose SARIMAX parameters or its forecasts.

## Key generated results (synthetic demonstration only)

- Customers: 1,200 across 4 clusters.
- SARIMAX holdout MAPE: about 3.63%; MAE about 69.88; RMSE about 89.31 (metric units are sales units).
- Forecast horizon: October 2026 to September 2027.
- Most influential feature in the auxiliary Random Forest by mean absolute SHAP: `lag_12`.

See `Data_Science_Whitepaper.pdf` for charts, tables, interpretation and caveats.
