from pathlib import Path
import nbformat as nbf

root = Path(__file__).resolve().parent
nb = nbf.v4.new_notebook()
nb.metadata = {
    "kernelspec": {"display_name": "Python 3", "language": "python", "name": "python3"},
    "language_info": {"name": "python", "version": "3.x"},
}
cells = []
cells.append(nbf.v4.new_markdown_cell("""# Data Science Project - Tasks 2-4

This notebook accompanies the solution for **Automated Web Scraping**, **K-Means Customer Segmentation**, and **Time-Series Forecasting + Interpretability**.

**Data caveat:** no real dataset was supplied. Customer and monthly-sales records are synthetic demonstration data. The web-scraping code targets Quotes to Scrape; live extraction requires internet access. The bundled parser fixture is not presented as a live scrape.

Run from the extracted project directory. Install dependencies first with `pip install -r requirements.txt`."""))
cells.append(nbf.v4.new_markdown_cell("## Task 2 - Automated unstructured web scraping\nThe complete scraper lives in `task2_web_scraper.py`. It uses Requests and BeautifulSoup, handles pagination, cleans whitespace, extracts quote/author/tags, deduplicates records and writes CSV + SQLite. The cell below is intentionally commented out so notebook execution does not depend on external internet access."""))
cells.append(nbf.v4.new_code_cell("""# Live run (internet connection required):
# from task2_web_scraper import scrape_quotes
# live_quotes = scrape_quotes(max_pages=5, output_dir='outputs/task2_live_scrape', delay_seconds=1.0)
# live_quotes.head()"""))
cells.append(nbf.v4.new_markdown_cell("## Task 3 - Customer segmentation with standardization, elbow diagnostics and PCA"))
cells.append(nbf.v4.new_code_cell("""from pathlib import Path
import json
import pandas as pd
import matplotlib.pyplot as plt
from IPython.display import display, Image

ROOT = Path.cwd()
if not (ROOT / 'analysis_pipeline.py').exists():
    raise FileNotFoundError('Please start Jupyter in the extracted data_science_complete_solution directory.')
from analysis_pipeline import run_all, customer_clustering, time_series_forecasting

results = run_all()
print('Pipeline complete. Outputs are saved under outputs/ and figures/.')"""))
cells.append(nbf.v4.new_code_cell("""# Inspect synthetic raw data quality and final segment structure
raw_customers = pd.read_csv('data/customer_metrics_synthetic.csv')
print('Raw shape:', raw_customers.shape)
print('Missing values before cleaning:')
display(raw_customers.isna().sum().rename('missing_count').to_frame())
segments = pd.read_csv('outputs/customer_segments.csv')
print('Segmented shape:', segments.shape)
display(segments.head())"""))
cells.append(nbf.v4.new_code_cell("""# Elbow and silhouette diagnostics for k=2..8
diagnostics = pd.read_csv('outputs/cluster_diagnostics.csv')
display(diagnostics.round(3))
display(Image(filename='figures/elbow_method.png'))"""))
cells.append(nbf.v4.new_code_cell("""# Human-readable customer segment profiles
cluster_summary = pd.read_csv('outputs/cluster_summary.csv')
display(cluster_summary.round(2))
display(Image(filename='figures/customer_pca_clusters.png'))"""))
cells.append(nbf.v4.new_markdown_cell("""**Interpretation note:** the sample was deliberately generated with four latent profiles, so k=4 is chosen for demonstrating the workflow. In an actual engagement, cluster count needs to be justified from the elbow curve, silhouette scores, cluster stability and whether the segments are actionable."""))
cells.append(nbf.v4.new_markdown_cell("## Task 4 - Stationarity tests, seasonal differencing, SARIMAX forecast and confidence intervals"))
cells.append(nbf.v4.new_code_cell("""results = json.loads(Path('outputs/time_series_model_results.json').read_text(encoding='utf-8'))
print('Stationarity diagnostics:')
display(pd.DataFrame([results['adf']]).T.rename(columns={0:'value'}))
print('Model and holdout metrics:')
display(pd.DataFrame([results['sarima']]).T.rename(columns={0:'value'}))"""))
cells.append(nbf.v4.new_code_cell("""forecast = pd.read_csv('outputs/sales_forecast_12_months.csv', parse_dates=['date'])
display(forecast.round(2))
display(Image(filename='figures/sales_forecast.png'))"""))
cells.append(nbf.v4.new_markdown_cell("## Interpretability layer - SHAP feature importance"))
cells.append(nbf.v4.new_code_cell("""importance = pd.read_csv('outputs/feature_importance_shap.csv')
display(importance.round(3))
display(Image(filename='figures/shap_feature_importance.png'))"""))
cells.append(nbf.v4.new_markdown_cell("""SHAP is computed for an **auxiliary Random Forest model** that predicts a one-step-ahead sales value from lag/calendar variables. This makes the feature contributions interpretable, but the SHAP values are not direct explanations of the SARIMAX parameters. The full forecast, validation predictions, cluster CSVs, and model metrics are stored in `outputs/`.

## Reproduce and replace data

- Run `python analysis_pipeline.py` to regenerate all synthetic Task 3/4 data and outputs.
- Run `python task2_web_scraper.py --pages 5 --output-dir outputs/task2_live_scrape` from an internet-connected environment to create live scrape records.
- Replace the synthetic CSV files with approved real data, then update the data-preparation steps and assumptions before using the conclusions for business decisions."""))
nb.cells = cells
nbf.write(nb, root/'Data_Science_Project_Notebook.ipynb')
