"""Task 2: Polite public-web scraping and structured extraction pipeline.

Target: https://quotes.toscrape.com/ - a practice site made for web scraping.
This script writes a CSV and SQLite database. It does not bypass logins,
CAPTCHAs, or access controls. Check a site's terms and robots policy before
adapting it to other sources.
"""
from __future__ import annotations
import argparse
import re
import sqlite3
import time
from datetime import datetime, timezone
from pathlib import Path
from typing import Iterable

import pandas as pd
import requests
from bs4 import BeautifulSoup
from requests.adapters import HTTPAdapter
from urllib3.util.retry import Retry

BASE_URL = "https://quotes.toscrape.com/"
USER_AGENT = "EducationalDataScienceProject/1.0 (polite public-page scraper)"


def clean_text(value: str | None) -> str:
    """Collapse repeated whitespace and remove invisible spacing artifacts."""
    if not value:
        return ""
    value = value.replace("\xa0", " ").replace("\u200b", "")
    return re.sub(r"\s+", " ", value).strip()


def build_session() -> requests.Session:
    session = requests.Session()
    retries = Retry(total=3, connect=3, read=3, backoff_factor=0.7,
                    status_forcelist=(429, 500, 502, 503, 504),
                    allowed_methods=frozenset(["GET"]))
    session.mount("https://", HTTPAdapter(max_retries=retries))
    session.headers.update({"User-Agent": USER_AGENT, "Accept": "text/html,application/xhtml+xml"})
    return session


def parse_listing_page(html: str, page_url: str, captured_at: str) -> list[dict]:
    soup = BeautifulSoup(html, "html.parser")
    records = []
    for item in soup.select("div.quote"):
        quote = clean_text(item.select_one("span.text").get_text(" ", strip=True) if item.select_one("span.text") else "")
        author = clean_text(item.select_one("small.author").get_text(" ", strip=True) if item.select_one("small.author") else "")
        tags = [clean_text(tag.get_text(" ", strip=True)) for tag in item.select("a.tag")]
        if not quote or not author:
            continue
        # Basic text filtering: ensure extracted body has meaningful content.
        if len(quote) < 8 or not re.search(r"[A-Za-z]", quote):
            continue
        records.append({
            "quote": quote,
            "author": author,
            "tags": "|".join(t for t in tags if t),
            "source_url": page_url,
            "scraped_at_utc": captured_at,
            "quote_char_count": len(quote),
            "quote_word_count": len(quote.split()),
        })
    return records


def scrape_quotes(max_pages: int = 5, output_dir: str | Path = "outputs", delay_seconds: float = 1.0) -> pd.DataFrame:
    if max_pages < 1:
        raise ValueError("max_pages must be at least 1")
    output = Path(output_dir)
    output.mkdir(parents=True, exist_ok=True)
    session = build_session()
    all_rows: list[dict] = []
    next_url: str | None = BASE_URL
    captured_at = datetime.now(timezone.utc).isoformat(timespec="seconds")

    for page_number in range(1, max_pages + 1):
        if not next_url:
            break
        response = session.get(next_url, timeout=20)
        response.raise_for_status()
        response.encoding = response.apparent_encoding
        page_rows = parse_listing_page(response.text, response.url, captured_at)
        all_rows.extend(page_rows)
        soup = BeautifulSoup(response.text, "html.parser")
        next_link = soup.select_one("li.next a")
        next_url = requests.compat.urljoin(response.url, next_link.get("href")) if next_link else None
        if next_url and page_number < max_pages and delay_seconds > 0:
            time.sleep(delay_seconds)

    df = pd.DataFrame(all_rows, columns=["quote", "author", "tags", "source_url", "scraped_at_utc", "quote_char_count", "quote_word_count"])
    if df.empty:
        raise RuntimeError("No records extracted. Check the URL, network access, and page selectors.")
    df = df.drop_duplicates(subset=["quote", "author"]).reset_index(drop=True)
    csv_path = output / "quotes_scraped.csv"
    db_path = output / "quotes_scraped.sqlite"
    df.to_csv(csv_path, index=False, encoding="utf-8")
    with sqlite3.connect(db_path) as con:
        df.to_sql("quote_records", con, if_exists="replace", index=False)
        con.execute("CREATE INDEX IF NOT EXISTS idx_quote_author ON quote_records(author)")
    print(f"Extracted {len(df):,} unique records")
    print(f"CSV: {csv_path.resolve()}\nSQLite: {db_path.resolve()}")
    return df


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--pages", type=int, default=5, help="Maximum number of listing pages (default: 5)")
    parser.add_argument("--output-dir", default="outputs/task2_live_scrape", help="Output directory")
    parser.add_argument("--delay", type=float, default=1.0, help="Delay between pages in seconds")
    args = parser.parse_args()
    try:
        scrape_quotes(args.pages, args.output_dir, args.delay)
    except requests.RequestException as exc:
        raise SystemExit(f"Network/request failure: {exc}\nRun again when internet access is available. No sample rows are being mislabeled as live-scraped data.")

if __name__ == "__main__":
    main()
