"""Offline-reproducible analysis pipeline for Data Science Tasks 3 and 4.

The included customer and monthly-sales data are SYNTHETIC demonstrations, not
real customer or enterprise records. All random generation is seeded.
"""
from __future__ import annotations
import json
import warnings
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from sklearn.cluster import KMeans
from sklearn.decomposition import PCA
from sklearn.ensemble import RandomForestRegressor
from sklearn.metrics import mean_absolute_error, mean_squared_error, silhouette_score
from sklearn.preprocessing import StandardScaler
from statsmodels.tsa.stattools import adfuller
from statsmodels.tsa.statespace.sarimax import SARIMAX

ROOT = Path(__file__).resolve().parent
DATA = ROOT / "data"
OUTPUTS = ROOT / "outputs"
FIGURES = ROOT / "figures"


def ensure_dirs() -> None:
    for p in (DATA, OUTPUTS, FIGURES):
        p.mkdir(parents=True, exist_ok=True)


def generate_customer_data(n: int = 1200, seed: int = 42) -> pd.DataFrame:
    """Generate a demo consumer table with four intentionally distinct profiles."""
    rng = np.random.default_rng(seed)
    # Segment priors: value-seeking, premium loyal, casual, high-potential.
    groups = rng.choice(4, size=n, p=[0.27, 0.20, 0.31, 0.22])
    params = {
        0: dict(age=(35, 10), income=(42, 13), spend=(37, 13), freq=(3.0, 1.3), aov=(42, 13), online=(0.38, .16), returns=(.11, .045)),
        1: dict(age=(43, 9), income=(105, 24), spend=(82, 10), freq=(8.5, 2.0), aov=(135, 28), online=(.62, .15), returns=(.035, .02)),
        2: dict(age=(29, 11), income=(48, 16), spend=(35, 18), freq=(2.0, 1.0), aov=(37, 15), online=(.72, .17), returns=(.09, .05)),
        3: dict(age=(32, 9), income=(82, 19), spend=(70, 12), freq=(5.6, 1.6), aov=(82, 19), online=(.83, .10), returns=(.055, .03)),
    }
    records = []
    regions = np.array(["North", "South", "East", "West"])
    for i, g in enumerate(groups):
        p = params[int(g)]
        records.append({
            "customer_id": f"C{i+1:05d}",
            "age": int(np.clip(rng.normal(*p["age"]), 18, 78)),
            "annual_income_k": round(float(np.clip(rng.normal(*p["income"]), 12, 180)), 2),
            "spending_score": round(float(np.clip(rng.normal(*p["spend"]), 1, 100)), 2),
            "purchase_frequency_monthly": round(float(np.clip(rng.normal(*p["freq"]), 0.1, 15)), 2),
            "average_order_value": round(float(np.clip(rng.normal(*p["aov"]), 8, 250)), 2),
            "online_purchase_ratio": round(float(np.clip(rng.normal(*p["online"]), 0, 1)), 3),
            "return_rate": round(float(np.clip(rng.normal(*p["returns"]), 0, .35)), 3),
            "region": str(rng.choice(regions)),
        })
    df = pd.DataFrame(records)
    # Small controlled perturbations create realistic QA work without destabilizing demo.
    if n >= 100:
        miss_idx = rng.choice(df.index, size=max(2, n // 200), replace=False)
        df.loc[miss_idx, "online_purchase_ratio"] = np.nan
    return df


def customer_clustering() -> dict:
    ensure_dirs()
    raw_path = DATA / "customer_metrics_synthetic.csv"
    if raw_path.exists():
        raw = pd.read_csv(raw_path)
    else:
        raw = generate_customer_data()
        raw.to_csv(raw_path, index=False)

    df = raw.copy()
    initial_rows = len(df)
    df = df.drop_duplicates(subset=["customer_id"]).copy()
    features = ["age", "annual_income_k", "spending_score", "purchase_frequency_monthly",
                "average_order_value", "online_purchase_ratio", "return_rate"]
    for col in features:
        df[col] = pd.to_numeric(df[col], errors="coerce")
        df[col] = df[col].fillna(df[col].median())
    # Clip extreme numeric values at the 1st/99th percentile for stability, preserving data rows.
    for col in features:
        lo, hi = df[col].quantile([0.01, 0.99])
        df[col] = df[col].clip(lo, hi)

    scaler = StandardScaler()
    X = scaler.fit_transform(df[features])
    k_values = list(range(2, 9))
    inertias, silhouettes = [], []
    models = {}
    for k in k_values:
        model = KMeans(n_clusters=k, n_init=20, random_state=42)
        labels = model.fit_predict(X)
        models[k] = (model, labels)
        inertias.append(float(model.inertia_))
        silhouettes.append(float(silhouette_score(X, labels)))
    # Four profiles were deliberately generated; choose k=4 for this demo and report the diagnostics.
    selected_k = 4
    model, labels = models[selected_k]
    df["cluster_id"] = labels

    # Human-readable cluster names from normalized feature profiles.
    means = df.groupby("cluster_id")[features].mean()
    high_income = means["annual_income_k"].rank(pct=True)
    high_spend = means["spending_score"].rank(pct=True)
    high_freq = means["purchase_frequency_monthly"].rank(pct=True)
    segment_names = {}
    for cid, row in means.iterrows():
        if row["annual_income_k"] >= 90 and row["spending_score"] >= 75:
            name = "Premium Loyalists"
        elif row["purchase_frequency_monthly"] >= 4.5 and row["spending_score"] >= 60:
            name = "High-Potential Shoppers"
        elif row["online_purchase_ratio"] >= 0.60 and row["purchase_frequency_monthly"] < 3.2:
            name = "Digital Casuals"
        else:
            name = "Occasional Value Seekers"
        segment_names[int(cid)] = name
    # Keep label uniqueness if two clusters map to same descriptor.
    used = {}
    for cid in sorted(segment_names):
        name = segment_names[cid]
        used[name] = used.get(name, 0) + 1
        if used[name] > 1:
            segment_names[cid] = f"{name} {used[name]}"
    df["segment_name"] = df["cluster_id"].map(segment_names)

    pca = PCA(n_components=2, random_state=42)
    xy = pca.fit_transform(X)
    df["pca_1"], df["pca_2"] = xy[:, 0], xy[:, 1]

    summary = df.groupby(["cluster_id", "segment_name"], as_index=False).agg(
        customers=("customer_id", "count"), avg_age=("age", "mean"), avg_income_k=("annual_income_k", "mean"),
        avg_spending_score=("spending_score", "mean"), avg_monthly_frequency=("purchase_frequency_monthly", "mean"),
        avg_order_value=("average_order_value", "mean"), avg_online_ratio=("online_purchase_ratio", "mean"),
        avg_return_rate=("return_rate", "mean"))
    summary["customer_share_pct"] = summary["customers"] / summary["customers"].sum() * 100
    diagnostics = pd.DataFrame({"k": k_values, "inertia": inertias, "silhouette_score": silhouettes})

    df.to_csv(OUTPUTS / "customer_segments.csv", index=False)
    summary.to_csv(OUTPUTS / "cluster_summary.csv", index=False)
    diagnostics.to_csv(OUTPUTS / "cluster_diagnostics.csv", index=False)

    plt.figure(figsize=(7.5, 4.5))
    plt.plot(k_values, inertias, marker="o")
    plt.title("Elbow Method - Customer Clustering")
    plt.xlabel("Number of clusters (k)"); plt.ylabel("Inertia"); plt.xticks(k_values); plt.grid(alpha=.25)
    plt.tight_layout(); plt.savefig(FIGURES / "elbow_method.png", dpi=170); plt.close()

    plt.figure(figsize=(7.5, 5.0))
    scatter = plt.scatter(df["pca_1"], df["pca_2"], c=df["cluster_id"], cmap="viridis", alpha=.72, s=18)
    plt.title("Customer Segments in PCA Space"); plt.xlabel("Principal Component 1"); plt.ylabel("Principal Component 2")
    plt.colorbar(scatter, label="Cluster ID"); plt.grid(alpha=.15); plt.tight_layout()
    plt.savefig(FIGURES / "customer_pca_clusters.png", dpi=170); plt.close()

    return {"raw_rows": initial_rows, "clean_rows": len(df), "features": features, "selected_k": selected_k,
            "silhouette_selected": float(diagnostics.loc[diagnostics.k == selected_k, "silhouette_score"].iloc[0]),
            "pca_variance_explained": [float(x) for x in pca.explained_variance_ratio_],
            "cluster_summary": summary.to_dict(orient="records"), "diagnostics": diagnostics.to_dict(orient="records")}


def generate_monthly_sales(seed: int = 21) -> pd.DataFrame:
    rng = np.random.default_rng(seed)
    dates = pd.date_range("2017-01-01", "2026-09-01", freq="MS")
    t = np.arange(len(dates))
    # Synthetic monthly business metric: trend, annual seasonality and modest noise.
    seasonal = 170 * np.sin(2 * np.pi * (dates.month.to_numpy() - 1) / 12 - .7)
    holiday_lift = np.where(dates.month.to_numpy() == 12, 240, 0) + np.where(dates.month.to_numpy() == 11, 95, 0)
    values = 1450 + 5.0 * t + seasonal + holiday_lift + rng.normal(0, 68, len(dates))
    values = np.maximum(values, 500)
    return pd.DataFrame({"date": dates, "monthly_sales": np.round(values, 2)})


def make_ts_features(df: pd.DataFrame) -> pd.DataFrame:
    out = df.copy().sort_values("date")
    out["time_index"] = np.arange(len(out))
    out["month"] = out["date"].dt.month
    out["month_sin"] = np.sin(2 * np.pi * out["month"] / 12)
    out["month_cos"] = np.cos(2 * np.pi * out["month"] / 12)
    out["lag_1"] = out["monthly_sales"].shift(1)
    out["lag_2"] = out["monthly_sales"].shift(2)
    out["lag_12"] = out["monthly_sales"].shift(12)
    out["rolling_mean_3"] = out["monthly_sales"].shift(1).rolling(3).mean()
    return out.dropna().reset_index(drop=True)


def time_series_forecasting() -> dict:
    ensure_dirs()
    ts_path = DATA / "monthly_sales_synthetic.csv"
    if ts_path.exists():
        ts = pd.read_csv(ts_path, parse_dates=["date"])
    else:
        ts = generate_monthly_sales()
        ts.to_csv(ts_path, index=False, date_format="%Y-%m-%d")
    ts = ts.sort_values("date").reset_index(drop=True)
    series = ts.set_index("date")["monthly_sales"].asfreq("MS")
    raw_adf = adfuller(series, autolag="AIC")
    seasonally_diff = series.diff(12).dropna()
    seasonal_adf = adfuller(seasonally_diff, autolag="AIC")
    seasonal_then_regular_diff = series.diff(12).diff().dropna()
    combined_diff_adf = adfuller(seasonal_then_regular_diff, autolag="AIC")

    # Hold out the final 12 months to estimate out-of-sample performance.
    train, test = series.iloc[:-12], series.iloc[-12:]
    with warnings.catch_warnings():
        warnings.simplefilter("ignore")
        validation_model = SARIMAX(train, order=(1, 0, 1), seasonal_order=(1, 1, 1, 12),
                                   enforce_stationarity=False, enforce_invertibility=False).fit(disp=False, maxiter=200)
        validation_forecast = validation_model.get_forecast(steps=len(test)).predicted_mean
    val_pred = pd.Series(np.asarray(validation_forecast), index=test.index)
    val_mae = float(mean_absolute_error(test, val_pred))
    val_rmse = float(np.sqrt(mean_squared_error(test, val_pred)))
    val_mape = float(np.mean(np.abs((test.values - val_pred.values) / np.maximum(np.abs(test.values), 1))) * 100)

    with warnings.catch_warnings():
        warnings.simplefilter("ignore")
        final_model = SARIMAX(series, order=(1, 0, 1), seasonal_order=(1, 1, 1, 12),
                              enforce_stationarity=False, enforce_invertibility=False).fit(disp=False, maxiter=200)
        forecast_obj = final_model.get_forecast(steps=12)
    forecast_mean = forecast_obj.predicted_mean
    conf = forecast_obj.conf_int(alpha=0.05)
    forecast = pd.DataFrame({
        "date": pd.date_range(series.index[-1] + pd.offsets.MonthBegin(1), periods=12, freq="MS"),
        "forecast_sales": np.asarray(forecast_mean),
        "lower_95": np.asarray(conf.iloc[:, 0]),
        "upper_95": np.asarray(conf.iloc[:, 1]),
    })
    history = ts.copy()
    forecast.to_csv(OUTPUTS / "sales_forecast_12_months.csv", index=False, date_format="%Y-%m-%d")
    pd.DataFrame({"actual_date": test.index, "actual_sales": test.values, "validation_forecast": val_pred.values}).to_csv(
        OUTPUTS / "sales_validation_holdout.csv", index=False, date_format="%Y-%m-%d")

    # SHAP wrapper: tree model over lag/calendar features explains drivers of one-step-ahead sales predictions.
    feat_df = make_ts_features(ts)
    feature_cols = ["time_index", "month_sin", "month_cos", "lag_1", "lag_2", "lag_12", "rolling_mean_3"]
    X, y = feat_df[feature_cols], feat_df["monthly_sales"]
    rf = RandomForestRegressor(n_estimators=350, max_depth=5, min_samples_leaf=2, random_state=42, n_jobs=-1)
    rf.fit(X, y)
    # Save model-native importance as a robust baseline; replace with SHAP values below when installed.
    importance = pd.DataFrame({"feature": feature_cols, "mean_abs_shap": np.nan, "model_feature_importance": rf.feature_importances_})
    shap_status = "not computed"
    try:
        import shap
        # Background/sample are deterministic and intentionally small for quick execution.
        sample = X.tail(min(60, len(X)))
        explainer = shap.TreeExplainer(rf)
        shap_values = explainer.shap_values(sample)
        shap_array = np.asarray(shap_values)
        if shap_array.ndim == 3:
            shap_array = shap_array[..., 0]
        importance["mean_abs_shap"] = np.abs(shap_array).mean(axis=0)
        shap_status = f"SHAP {getattr(shap, '__version__', 'available')} TreeExplainer, {len(sample)} samples"
        # Portable beeswarm/summary image from SHAP values.
        plt.figure(figsize=(7.5, 4.5))
        shap.summary_plot(shap_values, sample, plot_type="bar", show=False, max_display=7)
        plt.title("SHAP Feature Importance - One-Step Sales Model")
        plt.tight_layout(); plt.savefig(FIGURES / "shap_feature_importance.png", dpi=170, bbox_inches="tight"); plt.close()
    except Exception as exc:
        shap_status = f"SHAP unavailable in current environment; model importance fallback used ({type(exc).__name__})"
        plt.figure(figsize=(7.5, 4.5))
        imp = importance.sort_values("model_feature_importance", ascending=True)
        plt.barh(imp["feature"], imp["model_feature_importance"])
        plt.title("Random Forest Feature Importance (SHAP fallback)"); plt.xlabel("Feature importance")
        plt.tight_layout(); plt.savefig(FIGURES / "shap_feature_importance.png", dpi=170); plt.close()
    importance = importance.sort_values("mean_abs_shap", ascending=False, na_position="last")
    importance.to_csv(OUTPUTS / "feature_importance_shap.csv", index=False)

    plt.figure(figsize=(8.5, 4.8))
    plt.plot(ts["date"], ts["monthly_sales"], label="Historical sales", linewidth=1.6)
    plt.plot(forecast["date"], forecast["forecast_sales"], label="12-month forecast", linewidth=1.8)
    plt.fill_between(forecast["date"], forecast["lower_95"], forecast["upper_95"], alpha=.2, label="95% confidence interval")
    plt.axvline(ts["date"].max(), linestyle="--", linewidth=1, alpha=.7)
    plt.title("Monthly Sales Forecast with 95% Confidence Interval"); plt.xlabel("Month"); plt.ylabel("Sales units")
    plt.legend(); plt.grid(alpha=.2); plt.tight_layout(); plt.savefig(FIGURES / "sales_forecast.png", dpi=170); plt.close()

    adf_results = {
        "raw_adf_statistic": float(raw_adf[0]), "raw_adf_p_value": float(raw_adf[1]),
        "raw_stationary_at_5pct": bool(raw_adf[1] < 0.05),
        "seasonal_diff_adf_statistic": float(seasonal_adf[0]), "seasonal_diff_adf_p_value": float(seasonal_adf[1]),
        "seasonal_diff_stationary_at_5pct": bool(seasonal_adf[1] < 0.05),
        "seasonal_plus_regular_diff_adf_statistic": float(combined_diff_adf[0]),
        "seasonal_plus_regular_diff_adf_p_value": float(combined_diff_adf[1]),
        "seasonal_plus_regular_diff_stationary_at_5pct": bool(combined_diff_adf[1] < 0.05),
    }
    model_results = {"order": [1,0,1], "seasonal_order": [1,1,1,12], "validation_mae": val_mae,
                     "validation_rmse": val_rmse, "validation_mape_pct": val_mape,
                     "aic_full_fit": float(final_model.aic), "bic_full_fit": float(final_model.bic),
                     "forecast_start": str(forecast["date"].min().date()), "forecast_end": str(forecast["date"].max().date()),
                     "forecast_mean": float(forecast["forecast_sales"].mean()),
                     "forecast_min": float(forecast["forecast_sales"].min()), "forecast_max": float(forecast["forecast_sales"].max()),
                     "interpretability_status": shap_status,
                     "top_features": importance.dropna(subset=["mean_abs_shap"]).head(5)["feature"].tolist() or
                                     importance.sort_values("model_feature_importance", ascending=False).head(5)["feature"].tolist()}
    results = {"adf": adf_results, "sarima": model_results, "observations": int(len(ts)),
               "last_historical_date": str(ts["date"].max().date()), "customer_rows": int(len(pd.read_csv(OUTPUTS / "customer_segments.csv"))) if (OUTPUTS / "customer_segments.csv").exists() else None}
    (OUTPUTS / "time_series_model_results.json").write_text(json.dumps(results, indent=2), encoding="utf-8")
    return results


def run_all() -> dict:
    ensure_dirs()
    cluster = customer_clustering()
    forecast = time_series_forecasting()
    summary = {"customer_clustering": cluster, "time_series_forecasting": forecast}
    (OUTPUTS / "project_results_summary.json").write_text(json.dumps(summary, indent=2), encoding="utf-8")
    return summary

if __name__ == "__main__":
    print(json.dumps(run_all(), indent=2))
